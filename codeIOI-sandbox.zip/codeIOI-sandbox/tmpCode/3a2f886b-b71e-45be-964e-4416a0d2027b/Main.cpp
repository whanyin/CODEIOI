#include using namespace std;

int main() { 
    int first_number, second_number, sum;

cout << "Enter two integers: "; 

cin >> first_number >> second_number;


return 0; } 