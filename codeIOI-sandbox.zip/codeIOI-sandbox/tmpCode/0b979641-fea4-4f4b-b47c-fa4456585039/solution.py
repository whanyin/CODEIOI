def solve():
    import sys
    input = sys.stdin.read
    data = input().split()
    
    N = int(data[0])
    m = int(data[1])
    k = list(map(int, data[2:2 + m]))
    k.sort()
    
    count = 0
    for num in k:
        if N >= num:
            N -= num
            count += 1
        else:
            break
    
    print(count)

solve()