#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    long long N;
    cin >> N;
    int totalMinutes = N % (24 * 60);
    int hours = totalMinutes / 60;
    int minutes = totalMinutes % 60;
    cout << setw(2) << setfill('0') << hours 
         << setw(2) << setfill('0') << minutes << endl;
    return 0;
}