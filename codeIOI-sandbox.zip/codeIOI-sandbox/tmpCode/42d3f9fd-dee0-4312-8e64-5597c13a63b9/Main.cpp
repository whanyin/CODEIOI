from typing import List

class Solution:
    def findMedianSortedArrays(self, nums1: List[int], nums2: List[int]) -> float:
        if len(nums1) > len(nums2):
            nums1, nums2 = nums2, nums1

        m, n = len(nums1), len(nums2)
        imin, imax = 0, m
        half_len = (m + n + 1) // 2

        while imin <= imax:
            i = (imin + imax) // 2
            j = half_len - i

            max_left_x = float('-inf') if i == 0 else nums1[i - 1]
            min_right_x = float('inf') if i == m else nums1[i]

            max_left_y = float('-inf') if j == 0 else nums2[j - 1]
            min_right_y = float('inf') if j == n else nums2[j]

            if max_left_x <= min_right_y and max_left_y <= min_right_x:
                if (m + n) % 2 == 0:
                    return (max(max_left_x, max_left_y) + min(min_right_x, min_right_y)) / 2.0
                else:
                    return max(max_left_x, max_left_y)
            elif max_left_x > min_right_y:
                imax = i - 1
            else:
                imin = i + 1

        raise ValueError("Input arrays are not valid")

def parse_input():
    m, n = map(int, input().split())
    nums1 = []
    nums2 = []
    if m > 0:
        line1 = input().strip()
        nums1 = list(map(int, line1.split()))
    else:
        input()
    if n > 0:
        line2 = input().strip()
        nums2 = list(map(int, line2.split()))
    else:
        input()
    return nums1, nums2

if __name__ == "__main__":
    nums1, nums2 = parse_input()
    sol = Solution()
    result = sol.findMedianSortedArrays(nums1, nums2)
    print(f"{result:.5f}")