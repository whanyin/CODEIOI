import sys

def main():
    data = sys.stdin.read().split()
    ptr = 0
    N = int(data[ptr]); ptr +=1
    m = int(data[ptr]); ptr +=1
    k = []
    for _ in range(m):
        k.append(int(data[ptr]))
        ptr +=1
    
    k.sort()
    count = 0
    remaining = N
    for num in k:
        if remaining >= num:
            remaining -= num
            count +=1
        else:
            break
    print(count)

if __name__ == "__main__":
    main()