#include <iostream>
#include <string>
using namespace std;

string longestNumericSubstring(const string& s) {
    int max_start = 0, max_len = 0;
    int current_start = 0, current_len = 0;
    bool digit_found = false;

    for (int i = 0; i < s.size(); ++i) {
        if (isdigit(s[i])) {
            if (current_len == 0) current_start = i;
            current_len++;
            digit_found = true;
        } else {
            if (current_len > max_len) {
                max_len = current_len;
                max_start = current_start;
            }
            current_len = 0;
        }
    }
    // Check for digits at the end
    if (current_len > max_len) {
        max_len = current_len;
        max_start = current_start;
    }
    return digit_found ? s.substr(max_start, max_len) : "No digits found";
}

int main() {
    string s;
    cin >> s;
    cout << longestNumericSubstring(s) << endl;
    return 0;
}