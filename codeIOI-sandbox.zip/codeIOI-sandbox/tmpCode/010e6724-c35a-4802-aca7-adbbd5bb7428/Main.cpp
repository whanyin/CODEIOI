#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int longestDigitSubstring(const string& s) {
    int max_len = 0, current_len = 0;
    for (char c : s) {
        if (isdigit(c)) {
            current_len++;
            max_len = max(max_len, current_len);
        } else {
            current_len = 0;
        }
    }
    return max_len;
}

int main() {
    string s;
    cin >> s; // 输入字符串
    cout << longestDigitSubstring(s) << endl;
    return 0;
}