#include <bits/stdc++.h>
using namespace std;
using ll = long long;

struct Edge {
    int to, rev;
    ll cap, cost;
};

class MinCostFlow {
    vector<vector<Edge>> g;
    vector<ll> dist, pot;
    vector<pair<int,int>> parent;
    
public:
    MinCostFlow(int n) : g(n), dist(n), pot(n), parent(n) {}
    
    void addEdge(int u, int v, ll cap, ll cost) {
        g[u].push_back({v, (int)g[v].size(), cap, cost});
        g[v].push_back({u, (int)g[u].size()-1, 0, -cost});
    }
    
    pair<ll,ll> solve(int s, int t) {
        ll flow = 0, cost = 0;
        while(true) {
            fill(dist.begin(), dist.end(), LLONG_MAX);
            dist[s] = 0;
            priority_queue<pair<ll,int>, vector<pair<ll,int>>, greater<>> pq;
            pq.push({0, s});
            
            while(!pq.empty()) {
                auto [d, u] = pq.top(); pq.pop();
                if(d > dist[u]) continue;
                for(auto &e : g[u]) {
                    ll nd = dist[u] + e.cost + pot[u] - pot[e.to];
                    if(e.cap > 0 && nd < dist[e.to]) {
                        dist[e.to] = nd;
                        parent[e.to] = {u, e.rev};
                        pq.push({nd, e.to});
                    }
                }
            }
            
            if(dist[t] == LLONG_MAX) break;
            
            for(int i = 0; i < g.size(); i++)
                if(dist[i] != LLONG_MAX) pot[i] += dist[i];
            
            ll f = LLONG_MAX;
            for(int v = t; v != s; v = parent[v].first)
                f = min(f, g[parent[v].first][g[v][parent[v].second].rev].cap);
            
            flow += f;
            cost += f * pot[t];
            
            for(int v = t; v != s; v = parent[v].first) {
                auto &e = g[parent[v].first][g[v][parent[v].second].rev];
                e.cap -= f;
                g[v][parent[v].second].cap += f;
            }
        }
        return {flow, cost};
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int N, M, K;
    cin >> N >> M >> K;
    
    MinCostFlow mcf(N + M + 2);
    int source = 0, sink = N + M + 1;
    
    // Read weight matrix and build edges
    vector<vector<ll>> weights(N+1, vector<ll>(M+1));
    for(int i = 1; i <= N; i++) {
        for(int j = 1; j <= M; j++) {
            cin >> weights[i][j];
            mcf.addEdge(i, N+j, 1, -weights[i][j]); // Negative for maximization
        }
    }
    
    // Read forbidden pairs and remove those edges
    while(K--) {
        int a, b;
        cin >> a >> b;
        for(auto it = mcf.g[a].begin(); it != mcf.g[a].end(); ) {
            if(it->to == N+b) {
                it = mcf.g[a].erase(it);
                break;
            } else {
                ++it;
            }
        }
    }
    
    // Connect source to Set A and Set B to sink
    for(int i = 1; i <= N; i++) mcf.addEdge(source, i, 1, 0);
    for(int j = 1; j <= M; j++) mcf.addEdge(N+j, sink, 1, 0);
    
    auto [flow, cost] = mcf.solve(source, sink);
    cout << -cost << "\n"; // Negate back to get maximum
    
    return 0;
}