import sys
from typing import List

class Solution:
    def findMedianSortedArrays(self, nums1: List[int], nums2: List[int]) -> float:
        if len(nums1) > len(nums2):
            nums1, nums2 = nums2, nums1

        m, n = len(nums1), len(nums2)
        if m == 0:
            mid = n // 2
            return float(nums2[mid]) if n % 2 else (nums2[mid - 1] + nums2[mid]) / 2.0

        imin, imax = 0, m
        half_len = (m + n + 1) // 2

        while imin <= imax:
            i = (imin + imax) // 2
            j = half_len - i

            max_left_x = float('-inf') if i == 0 else nums1[i - 1]
            min_right_x = float('inf') if i == m else nums1[i]

            max_left_y = float('-inf') if j == 0 else nums2[j - 1]
            min_right_y = float('inf') if j == n else nums2[j]

            if max_left_x <= min_right_y and max_left_y <= min_right_x:
                if (m + n) % 2 == 0:
                    return (max(max_left_x, max_left_y) + min(min_right_x, min_right_y)) / 2.0
                else:
                    return max(max_left_x, max_left_y)
            elif max_left_x > min_right_y:
                imax = i - 1
            else:
                imin = i + 1

        raise ValueError("Input arrays are not valid")

def parse_input():
    lines = list(filter(None, map(str.strip, sys.stdin.read().splitlines())))
    m, n = map(int, lines[0].split())
    nums1 = list(map(int, lines[1].split())) if m > 0 else []
    nums2 = list(map(int, lines[2 if m > 0 else 1].split())) if n > 0 else []
    return nums1, nums2

if __name__ == "__main__":
    nums1, nums2 = parse_input()
    sol = Solution()
    result = sol.findMedianSortedArrays(nums1, nums2)
    print(f"{result:.5f}")