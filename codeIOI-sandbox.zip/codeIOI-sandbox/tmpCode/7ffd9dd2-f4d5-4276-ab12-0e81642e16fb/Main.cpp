#include <iostream>

int main() {
    int a, b;
    cin >> a >> b;
    cout << a + b << std::endl;
    return 0;
}