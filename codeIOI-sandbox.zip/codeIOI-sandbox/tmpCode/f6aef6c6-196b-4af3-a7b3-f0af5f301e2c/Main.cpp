import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        long result = 1;

        // 故意使用极慢的方式计算阶乘，导致超时
        for (int i = 1; i <= N; i++) {
            // 用一个极慢的循环来拖延时间
            for (int j = 0; j < 1000000; j++) {
                // 空循环，浪费时间
            }
            result *= i;
        }

        System.out.println(result);
    }
}