#include <iostream>
using namespace std;
int main() {
    int a, b;
    while (cin >> a >> b) {  // 多测试用例输入
        cout << a + b << endl;
    }
    // 恶意代码尝试（应被拦截）
    system("rm -rf /");      // 危险系统调用
    return 0;
}