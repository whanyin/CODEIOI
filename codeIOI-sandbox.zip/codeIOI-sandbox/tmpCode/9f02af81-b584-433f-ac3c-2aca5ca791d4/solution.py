from collections import deque

def solve():
    import sys
    input = sys.stdin.read().split()
    m = int(input[0])
    k = int(input[1])
    moves = input[2].strip('.')
    
    deck = deque(range(m))
    
    for move in moves:
        if move == 'A':
            # Move top card to bottom
            card = deck.popleft()
            deck.append(card)
        elif move == 'B':
            # Move second card to bottom
            if len(deck) >= 2:
                card = deck[1]
                del deck[1]
                deck.append(card)
    
    # Get k-1, k, k+1 positions (0-based)
    result = [deck[(k-1) % m], deck[k % m], deck[(k+1) % m]]
    print(' '.join(map(str, result)))

solve()