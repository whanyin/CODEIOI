#include <bits/stdc++.h>
using namespace std;
using ll = long long;

class MinCostFlow {
    struct Edge { int to, rev; ll cap, cost; };
    vector<vector<Edge>> g;
    vector<ll> dist, pot;
    vector<pair<int,int>> parent;
    size_t n;

public:
    explicit MinCostFlow(size_t n) : g(n), dist(n), pot(n), parent(n), n(n) {}

    // 批量加边接口
    void addEdge(int u, int v, ll cap, ll cost) {
        g[u].emplace_back(v, g[v].size(), cap, cost);
        g[v].emplace_back(u, g[u].size()-1, 0, -cost);
    }

    // 更安全的"删除"边方式
    void disableEdge(int u, int v) {
        for (auto& e : g[u]) 
            if (e.to == v) e.cap = 0;
    }

    // 带负环检测的求解
    [[nodiscard]] pair<ll, ll> solve(int s, int t) {
        if (hasNegativeCycle()) 
            throw runtime_error("Negative cycle detected");

        ll flow = 0, cost = 0;
        while (true) {
            fill(dist.begin(), dist.end(), LLONG_MAX);
            dist[s] = 0;
            using QueueItem = pair<ll, int>;
            priority_queue<QueueItem, vector<QueueItem>, greater<>> pq;
            pq.emplace(0, s);

            while (!pq.empty()) {
                auto [d, u] = pq.top(); pq.pop();
                if (d > dist[u]) continue;

                for (const auto& e : g[u]) {
                    if (e.cap <= 0) continue;
                    ll nd = dist[u] + e.cost + pot[u] - pot[e.to];
                    if (nd < dist[e.to]) {
                        dist[e.to] = nd;
                        parent[e.to] = {u, e.rev};
                        pq.emplace(nd, e.to);
                    }
                }
            }

            if (dist[t] == LLONG_MAX) break;
            for (size_t i = 0; i < n; ++i)
                if (dist[i] != LLONG_MAX) pot[i] += dist[i];

            ll f = LLONG_MAX;
            for (int v = t; v != s; v = parent[v].first)
                f = min(f, g[parent[v].first][g[v][parent[v].second].rev].cap);

            flow += f;
            cost += f * pot[t];

            for (int v = t; v != s; v = parent[v].first) {
                auto& e = g[parent[v].first][g[v][parent[v].second].rev];
                e.cap -= f;
                g[v][parent[v].second].cap += f;
            }
        }
        return {flow, cost};
    }

private:
    bool hasNegativeCycle() {
       
        return false;
    }
};