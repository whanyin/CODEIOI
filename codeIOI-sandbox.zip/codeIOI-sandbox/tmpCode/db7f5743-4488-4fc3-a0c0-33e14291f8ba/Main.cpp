# 读取输入并拆分成两个整数
a, b = map(int, input().split())

# 输出它们的和
print(a + b)