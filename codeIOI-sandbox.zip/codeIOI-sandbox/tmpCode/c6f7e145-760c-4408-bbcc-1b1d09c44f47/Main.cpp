#include <iostream>
#include <vector>
using namespace std;

int longestValidParentheses(string s) {
    int n = s.size(), max_len = 0;
    int left = 0, right = 0;
    // 从左到右扫描
    for (int i = 0; i < n; ++i) {
        if (s[i] == '(') left++;
        else right++;
        if (left == right) max_len = max(max_len, 2 * right);
        else if (right > left) left = right = 0;
    }
    // 从右到左扫描（处理类似 "(()" 的情况）
    left = right = 0;
    for (int i = n - 1; i >= 0; --i) {
        if (s[i] == '(') left++;
        else right++;
        if (left == right) max_len = max(max_len, 2 * left);
        else if (left > right) left = right = 0;
    }
    return max_len;
}

int main() {
    string s;
    cin >> s;
    cout << longestValidParentheses(s) << endl;
    return 0;
}