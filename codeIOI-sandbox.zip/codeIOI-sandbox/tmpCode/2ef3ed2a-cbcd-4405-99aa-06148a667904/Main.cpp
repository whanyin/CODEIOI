#include <bits/stdc++.h>
using namespace std;
using ll = long long;

class MinCostFlow {
    struct Edge { int to, rev; ll cap, cost; };
    vector<vector<Edge>> g;
    vector<ll> dist, pot;
    vector<pair<int,int>> parent;

public:
    MinCostFlow(int n) : g(n), dist(n), pot(n), parent(n) {}

    void addEdge(int u, int v, ll cap, ll cost) {
        g[u].push_back({v, (int)g[v].size(), cap, cost});
        g[v].push_back({u, (int)g[u].size()-1, 0, -cost});
    }

    // 新增公有方法
    void removeEdge(int u, int v) {
        for (auto it = g[u].begin(); it != g[u].end(); ) {
            if (it->to == v) {
                it = g[u].erase(it);
                break;
            } else ++it;
        }
    }

    pair<ll,ll> solve(int s, int t) {
        ll flow = 0, cost = 0;
        while (true) {
            fill(dist.begin(), dist.end(), LLONG_MAX);
            dist[s] = 0;
            priority_queue<pair<ll,int>> pq;
            pq.push({0, s});

            while (!pq.empty()) {
                auto top = pq.top();
                ll d = -top.first;  // 默认优先队列是最大堆
                int u = top.second;
                pq.pop();
                if (d > dist[u]) continue;

                for (auto &e : g[u]) {
                    ll nd = dist[u] + e.cost + pot[u] - pot[e.to];
                    if (e.cap > 0 && nd < dist[e.to]) {
                        dist[e.to] = nd;
                        parent[e.to] = {u, e.rev};
                        pq.push({-nd, e.to});  // 负号实现最小堆
                    }
                }
            }
            if (dist[t] == LLONG_MAX) break;

            for (int i = 0; i < g.size(); ++i)
                if (dist[i] != LLONG_MAX) pot[i] += dist[i];

            ll f = LLONG_MAX;
            for (int v = t; v != s; v = parent[v].first)
                f = min(f, g[parent[v].first][g[v][parent[v].second].rev].cap);

            flow += f;
            cost += f * pot[t];

            for (int v = t; v != s; v = parent[v].first) {
                auto &e = g[parent[v].first][g[v][parent[v].second].rev];
                e.cap -= f;
                g[v][parent[v].second].cap += f;
            }
        }
        return {flow, cost};
    }
};