N = int(input())
total_minutes = N % (24 * 60)
hours = total_minutes // 60
minutes = total_minutes % 60
print(f"{hours:02d}{minutes:02d}")