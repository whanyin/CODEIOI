#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    long long N;
    cin >> N;
    long long total= N % (24 * 60);
    cout << setw(2) << setfill('0') << total / 60 
         << setw(2) << setfill('0') << total % 60 << endl
    return 0;
}