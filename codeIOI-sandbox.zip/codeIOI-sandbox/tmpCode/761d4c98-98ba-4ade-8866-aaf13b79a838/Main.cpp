#include <iostream>
using namespace std;
int main() {
    int x=5;
    int b=3;
    cout << max(a, b) << endl;
    return 0;
}