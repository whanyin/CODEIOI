#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>

using namespace std;

int lengthOfLIS(const vector<int>& nums) {
    if (nums.empty()) return 0;
    vector<int> dp;
    for (int num : nums) {
        auto it = lower_bound(dp.begin(), dp.end(), num);
        if (it == dp.end()) dp.push_back(num);
        else *it = num;
    }
    return dp.size();
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    vector<int> nums;
    int val;
    // 读入直到输入结束或换行
    string line;
    getline(cin, line);
    istringstream iss(line);
    while (iss >> val) {
        nums.push_back(val);
    }

    cout << lengthOfLIS(nums) << "\n";
    return 0;
}