#include <iostream>
#include <string>
using namespace std;

string longestNumericSubstring(const string& s) {
    int max_start = 0, max_len = 0;
    int current_start = 0, current_len = 0;
    
    for (int i = 0; i < s.size(); ++i) {
        if (isdigit(s[i])) {
            if (current_len == 0) current_start = i; // 新数字子串的起始位置
            current_len++;
        } else {
            if (current_len > max_len) {
                max_len = current_len;
                max_start = current_start;
            }
            current_len = 0;
        }
    }
    // 检查末尾的数字子串
    if (current_len > max_len) {
        max_len = current_len;
        max_start = current_start;
    }
    return (max_len > 0) ? s.substr(max_start, max_len) : "";
}

int main() {
    string s;
    cin >> s; // 输入字符串
    cout << longestNumericSubstring(s) << endl;
    return 0;
}