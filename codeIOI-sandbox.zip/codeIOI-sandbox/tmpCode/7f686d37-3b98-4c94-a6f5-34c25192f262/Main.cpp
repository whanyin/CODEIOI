#include <iostream>
#include <algorithm>
using namespace std;

struct TreeNode {
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
};

class Solution {
public:
    int maxDepth(TreeNode* root) {
        if (root == nullptr) return 0;
        int leftDepth = maxDepth(root->left);
        int rightDepth = maxDepth(root->right);
        return max(leftDepth, rightDepth) + 1;
    }
};

// 示例构造与调用
int main() {
    // 构建如下的二叉树:
    //      1
    //     / \
    //    2   3
    //   /
    //  4
    TreeNode* root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);

    Solution sol;
    int depth = sol.maxDepth(root);
    cout << depth << endl;  // 输出结果应为 3

    // 清理内存
    delete root->left->left;
    delete root->left;
    delete root->right;
    delete root;

    return 0;
}