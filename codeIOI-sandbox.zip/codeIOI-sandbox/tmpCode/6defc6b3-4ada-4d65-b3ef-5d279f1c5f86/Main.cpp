#include <iostream>
using namespace std;

int main() {
    int a, b;
    cin >> a >> b;
    int c = a / 0; // 故意除以0，产生运行时错误
    cout << c << endl
    return 0;
}