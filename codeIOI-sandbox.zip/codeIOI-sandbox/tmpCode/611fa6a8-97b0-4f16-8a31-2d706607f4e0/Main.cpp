#include <iostream>
using namespace std;
int main()
{
//Please enter your code here 
int a,b;
cin>>a>>b;
cout<<max(a,b)<<endl;
    return 0
}