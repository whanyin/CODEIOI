#include <iostream>
using namespace std;

int main() {
    int d;
    cin >> d;
    
    long long total = 0;
    for (int i = 0; i < d; ++i) {
        int meows;
        cin >> meows;
        total += meows;
    }
    
    cout << total << endl;
    return 0;
}