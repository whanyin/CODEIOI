package com.hanyin.codeioisandbox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeIoiSandboxApplicationTests {

    @Test
    void contextLoads() {
    }

}
