import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);
        System.out.println("result:" + (a + b));
    }
}
