package com.hanyin.codeioisandbox;

public class simpleCount {
    public static void main(String[] args) {
        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);
        System.out.println("结果是:"+a + b);
    }
}
