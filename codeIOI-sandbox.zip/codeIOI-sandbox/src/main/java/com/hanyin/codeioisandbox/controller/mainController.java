package com.hanyin.codeioisandbox.controller;

import com.hanyin.codeioisandbox.model.ExecuteCodeRequest;
import com.hanyin.codeioisandbox.model.ExecuteCodeResponse;
import com.hanyin.codeioisandbox.service.CodeSandBox;
import com.hanyin.codeioisandbox.strategy.SandboxManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.hanyin.codeioisandbox.constant.AuthConstant.AUTHREQUESTHEADER;
import static com.hanyin.codeioisandbox.constant.AuthConstant.AUTHREQUESTSECRET;

@RestController("/")
public class mainController {

    @GetMapping("/health")
    public String health() {
        return "ok";
    }

    @PostMapping("/executeCode")
    public ExecuteCodeResponse executeCode(@RequestBody ExecuteCodeRequest executeCodeRequest, HttpServletRequest request,
                                           HttpServletResponse response) {
        String authHeaders = request.getHeader(AUTHREQUESTHEADER);
        //基本认证
        if (!AUTHREQUESTSECRET.equals(authHeaders)) {
            response.setStatus(403);
            return null;
        }
        if (executeCodeRequest == null) {
            throw new RuntimeException("Parameter is empty");
        }
        String language = executeCodeRequest.getLanguage();
        CodeSandBox sandBox = SandboxManager.getSandBox(language);
        return sandBox.executeCode(executeCodeRequest);
    }
}
