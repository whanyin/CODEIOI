package com.hanyin.codeioisandbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeIoiSandboxApplication {

    public static void main(String[] args) {
        SpringApplication.run(CodeIoiSandboxApplication.class, args);
    }

}
