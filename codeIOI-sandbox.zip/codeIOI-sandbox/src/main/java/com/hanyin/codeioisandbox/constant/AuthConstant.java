package com.hanyin.codeioisandbox.constant;

public interface AuthConstant {
    String AUTHREQUESTHEADER = "7D6507E83D4EFFD42BCDC88753402B06";
    String AUTHREQUESTSECRET = "1BE6C9847772AF22C041AA082F228D44";
}
