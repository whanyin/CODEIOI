package com.hanyin.codeioisandbox.strategy;

import com.hanyin.codeioisandbox.service.CodeSandBox;
import com.hanyin.codeioisandbox.service.cpp.CppNativeCodeSandbox;
import com.hanyin.codeioisandbox.service.java.JavaNativeCodeSandbox;
import com.hanyin.codeioisandbox.service.python3.PythonNativeCodeSandbox;
import org.springframework.stereotype.Service;

/**
 * @author 15712
 * 判题管理，简化判题服务
 */
@Service
public class SandboxManager {


    public static CodeSandBox getSandBox(String language) {
        switch (language) {
            case "java":
                return new JavaNativeCodeSandbox();
            case "python":
                return new PythonNativeCodeSandbox();
            case "cpp":
                return new CppNativeCodeSandbox();
            default:
                throw new RuntimeException("The language is not supported");
        }

    }
}
