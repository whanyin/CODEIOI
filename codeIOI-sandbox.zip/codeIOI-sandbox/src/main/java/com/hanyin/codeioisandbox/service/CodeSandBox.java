package com.hanyin.codeioisandbox.service;

import com.hanyin.codeioisandbox.model.ExecuteCodeRequest;
import com.hanyin.codeioisandbox.model.ExecuteCodeResponse;

/**
 * @author 15712
 */
public interface CodeSandBox {

    ExecuteCodeResponse executeCode(ExecuteCodeRequest executeCodeRequest);
}
