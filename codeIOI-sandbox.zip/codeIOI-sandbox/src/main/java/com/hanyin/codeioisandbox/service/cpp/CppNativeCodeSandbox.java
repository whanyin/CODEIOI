package com.hanyin.codeioisandbox.service.cpp;

import com.hanyin.codeioisandbox.model.ExecuteCodeRequest;
import com.hanyin.codeioisandbox.model.ExecuteCodeResponse;
import org.springframework.stereotype.Component;



@Component
public class CppNativeCodeSandbox extends CppCodeSandboxTemplate {

    /**
     * 执行代码
     *
     * @return
     */
    @Override
    public ExecuteCodeResponse executeCode(ExecuteCodeRequest executeCodeRequest) {
        return super.executeCode(executeCodeRequest);
    }
}

