package com.hanyin.CodeIOI.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hanyin.CodeIOI.model.entity.User;

/**
 * User database operations
 */
public interface UserMapper extends BaseMapper<User> {

}




