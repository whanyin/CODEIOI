package com.hanyin.CodeIOI.judge.codeSandBox;

import com.hanyin.CodeIOI.judge.codeSandBox.model.ExecuteCodeRequest;
import com.hanyin.CodeIOI.judge.codeSandBox.model.ExecuteCodeResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CodeSandBoxProxy implements CodeSandBox {

    private final CodeSandBox codeSandbox;


    public CodeSandBoxProxy(CodeSandBox codeSandbox) {
        this.codeSandbox = codeSandbox;
    }

    @Override
    public ExecuteCodeResponse executeCode(ExecuteCodeRequest executeCodeRequest) {
        log.info("Code Sandbox Request Information：" + executeCodeRequest.toString());
        ExecuteCodeResponse executeCodeResponse = codeSandbox.executeCode(executeCodeRequest);
        log.info("Code Sandbox Response Information：" + executeCodeResponse.toString());
        return executeCodeResponse;
    }
}
