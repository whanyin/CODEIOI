package com.hanyin.CodeIOI.judge;

import com.hanyin.CodeIOI.judge.codeSandBox.model.ExecuteCodeRequest;
import com.hanyin.CodeIOI.judge.codeSandBox.model.ExecuteCodeResponse;
import com.hanyin.CodeIOI.model.entity.QuestionSubmit;

/**
 * 判题服务
 */
public interface JudgeService {

    QuestionSubmit doJudge(long questionSubmitId);
}
