package com.hanyin.CodeIOI.utils;

import cn.hutool.json.JSONUtil;
import com.hanyin.CodeIOI.model.enums.InputType;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;


public class InputParser {
    public static List<String> parse(InputType type, String rawInput) {
        switch (type) {
            case SINGLE_LINE:
                return Collections.singletonList(rawInput);

            case MULTI_LINE_GRID:
            case MULTI_LINE_ARRAY:
                return Arrays.stream(rawInput.split("\n"))
                        .map(String::trim)
                        .filter(line -> !line.isEmpty())
                        .collect(Collectors.toList());

            default:
                throw new IllegalArgumentException("未知输入类型: " + type);
        }
    }
}
