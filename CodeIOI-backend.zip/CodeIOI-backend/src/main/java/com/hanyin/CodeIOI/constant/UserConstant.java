package com.hanyin.CodeIOI.constant;

/**
 * User Constant
 */
public interface UserConstant {

    String USER_LOGIN_STATE = "user_login";
    String DEFAULT_ROLE = "user";
    String ADMIN_ROLE = "admin";
    String BAN_ROLE = "ban";

    String DEFAULT_AVATAR ="https://www.bing.com/th?id=OIP.x_j4oT7PxgXHjBxp7DRaYwHaHa&w=145&h=150&c=8&rs=1&qlt=90&o=6&dpr=2&pid=3.1&rm=2";
    /**
     * 默认随机生成用户名
     */
    String DEFAULT_USERNAME = "User-"+String.valueOf(System.currentTimeMillis()).substring(0,5);

}
