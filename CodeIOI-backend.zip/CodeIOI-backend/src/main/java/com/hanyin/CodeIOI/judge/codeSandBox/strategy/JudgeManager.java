package com.hanyin.CodeIOI.judge.codeSandBox.strategy;

import com.hanyin.CodeIOI.judge.codeSandBox.model.JudgeResult;
import org.springframework.stereotype.Service;

/**
 * 判题管理（简化调用）
 */
@Service
public class JudgeManager {
    public JudgeResult doJudge(JudgeContext judgeContext) {
        JudgeStrategy judgeStrategy = new DefaultJudgeStrategy();
        return judgeStrategy.doJudge(judgeContext);
    }

}
