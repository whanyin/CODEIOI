package com.hanyin.CodeIOI.judge.codeSandBox.strategy;

import com.hanyin.CodeIOI.judge.codeSandBox.model.JudgeInfo;
import com.hanyin.CodeIOI.judge.codeSandBox.model.JudgeResult;
import com.hanyin.CodeIOI.model.dto.question.JudgeCase;
import com.hanyin.CodeIOI.model.dto.question.JudgeSubTask;
import com.hanyin.CodeIOI.model.entity.Question;
import com.hanyin.CodeIOI.model.entity.QuestionSubmit;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * 上下文（用于定义在策略中传递的参数）
 */
@Data
public class JudgeContext {

    private JudgeResult judgeResult;

    private JudgeInfo judgeInfo;

    private List<JudgeSubTask> judgeSubTaskList;

    private Question question;

    private QuestionSubmit questionSubmit;

    private List<String> inputList;

    private List<String> actualOutputList;

    private List<String> expectedOutputList;

    private Integer status;


}
