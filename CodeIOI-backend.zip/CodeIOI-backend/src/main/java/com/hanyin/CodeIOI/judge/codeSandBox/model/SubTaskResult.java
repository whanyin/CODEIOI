package com.hanyin.CodeIOI.judge.codeSandBox.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
public class SubTaskResult {
    private Integer subTaskId;          // 子任务ID
    private Integer subTaskScore;         // 子任务满分
    private Integer earnedScore;    // 实际得分
    private boolean passed;             // 是否全部通过
    private List<TestCaseResult> caseResults; // 所有用例的详细结果
}
