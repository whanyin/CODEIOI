package com.hanyin.CodeIOI.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 使用正斜杠或双反斜杠均可（推荐正斜杠）
        String pdfPath = "file:D:/FYR/CodeIOI-backend/uploads/pdf/";

        registry.addResourceHandler("/uploads/pdf/**")
                .addResourceLocations(pdfPath);

    }
}