package com.hanyin.CodeIOI.model.dto.question;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 更新请求
 */
@Data
public class QuestionUpdateRequest implements Serializable {

    /**
     * id
     */
    private Long id;

    /**
     * 标题
     */
    private String title;

    private String contentType;

    /**
     * 内容
     */
    private String content;

    private String fileUrl;


    private String difficulty;
    /**
     * 标签列表
     */
    private List<String> tags;


    /**
     * 判题子任务
     */
    private List<JudgeSubTask> judgeTasks;

    /**
     * 判题配置（json 对象）
     */
    private JudgeConfig judgeConfig;

    private static final long serialVersionUID = 1L;
}