package com.hanyin.CodeIOI.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.hanyin.CodeIOI.model.dto.user.UserQueryRequest;
import com.hanyin.CodeIOI.model.entity.User;
import com.hanyin.CodeIOI.model.vo.LoginUserVO;
import com.hanyin.CodeIOI.model.vo.UserVO;
import me.chanjar.weixin.common.bean.WxOAuth2UserInfo;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 用户服务
 */
public interface UserService extends IService<User> {

    /**
     * user register
     *
     * @param userAccount
     * @param userPassword
     * @param checkPassword
     * @return new user id
     */
    long userRegister(String userAccount, String userPassword, String checkPassword);

    /**
     * user login
     *
     * @param userAccount
     * @param userPassword
     * @return Desensitized user information
     */
    LoginUserVO userLogin(String userAccount, String userPassword);

    User getLoginUser();

    /**
     * Get the currently logged in user (allows non-logged in users)
     *
     * @param request
     * @return
     */
    User getLoginUserPermitNull(HttpServletRequest request);

    /**
     * is admin?
     * @return
     */
    boolean isAdmin();

    /**
     * is admin?
     *
     * @param user
     * @return
     */
    boolean isAdmin(User user);

    /**
     * 用户注销
     *
     * @param request
     * @return
     */
    boolean userLogout(HttpServletRequest request);

    /**
     * 用户注销
     *
     * @return
     */
    boolean userLogout();

    /**
     * Get desensitized logged-in user information
     *
     * @return
     */
    LoginUserVO getLoginUserVO(User user);

    /**
     * Get desensitized logged-in user information
     *
     * @param user
     * @return
     */
    UserVO getUserVO(User user);

    /**
     * Get desensitized logged-in user information
     *
     * @param userList
     * @return
     */
    List<UserVO> getUserVO(List<User> userList);

    /**
     * Get query conditions
     *
     * @param userQueryRequest
     * @return
     */
    QueryWrapper<User> getQueryWrapper(UserQueryRequest userQueryRequest);

}
