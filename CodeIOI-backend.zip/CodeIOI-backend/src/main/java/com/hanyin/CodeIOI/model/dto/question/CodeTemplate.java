package com.hanyin.CodeIOI.model.dto.question;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 160201
 */
@NoArgsConstructor
@Data
public class CodeTemplate {
    private String python;
    private String cpp;
}
