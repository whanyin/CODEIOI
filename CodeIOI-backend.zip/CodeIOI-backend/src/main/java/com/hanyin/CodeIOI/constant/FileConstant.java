package com.hanyin.CodeIOI.constant;

/**
 * File constant
 */
public interface FileConstant {

    /**
     * COS 访问地址
     * todo 需替换配置
     */
    String COS_HOST = "https://hanyin.icu";
}
