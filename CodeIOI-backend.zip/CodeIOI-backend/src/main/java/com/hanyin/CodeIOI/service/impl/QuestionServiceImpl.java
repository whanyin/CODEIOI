package com.hanyin.CodeIOI.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.resource.ResourceUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hanyin.CodeIOI.common.BaseResponse;
import com.hanyin.CodeIOI.common.ErrorCode;
import com.hanyin.CodeIOI.common.ResultUtils;
import com.hanyin.CodeIOI.constant.CommonConstant;
import com.hanyin.CodeIOI.exception.BusinessException;
import com.hanyin.CodeIOI.exception.ThrowUtils;
import com.hanyin.CodeIOI.mapper.QuestionMapper;
import com.hanyin.CodeIOI.model.dto.question.CodeTemplate;
import com.hanyin.CodeIOI.model.dto.question.JudgeConfig;
import com.hanyin.CodeIOI.model.dto.question.JudgeSubTask;
import com.hanyin.CodeIOI.model.dto.question.QuestionQueryRequest;
import com.hanyin.CodeIOI.model.entity.*;
import com.hanyin.CodeIOI.model.vo.QuestionVO;
import com.hanyin.CodeIOI.model.vo.UserVO;
import com.hanyin.CodeIOI.service.QuestionService;
import com.hanyin.CodeIOI.service.UserService;
import com.hanyin.CodeIOI.utils.SqlUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class QuestionServiceImpl extends ServiceImpl<QuestionMapper, Question>
    implements QuestionService{


    @Resource
    private UserService userService;

    /**
     * 校验题目是否合法
     *
     * @param question
     * @param add
     */
    @Override
    public void validQuestion(Question question, boolean add) {
        if (question == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        String title = question.getTitle();
        String content = question.getContent();
        String fileUrl = question.getFileUrl();
        String tags = question.getTags();
        String judgeTask = question.getJudgeTasks();
        String judgeConfig = question.getJudgeConfig();
        // 创建时，参数不能为空
        if (add) {
            ThrowUtils.throwIf(StringUtils.isAnyBlank(title, tags), ErrorCode.PARAMS_ERROR);
        }
        // 有参数则校验
        if (StringUtils.isNotBlank(title) && title.length() > 80) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Title is too long");
        }
        if (StringUtils.isNotBlank(content) && content.length() > 8192) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Content is too long");
        }

        // 校验判题配置和子任务
        validateJudgeConfig(question.getJudgeConfig());
        validateJudgeTasks(question.getJudgeTasks());

    }
    private void validateJudgeConfig(String judgeConfigJson) {
        if (StringUtils.isBlank(judgeConfigJson)) return;

        try {
            JudgeConfig config = JSONUtil.toBean(judgeConfigJson, JudgeConfig.class);
            ThrowUtils.throwIf(config.getTimeLimit() == null || config.getMemoryLimit() == null,
                    ErrorCode.PARAMS_ERROR, "The configuration must include time and memory limits");
        } catch (Exception e) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Question configuration parsing failed");
        }
    }
    private void validateJudgeTasks(String judgeTasksJson) {
        if (StringUtils.isBlank(judgeTasksJson)) return;

        try {
            List<JudgeSubTask> tasks = JSONUtil.toList(judgeTasksJson, JudgeSubTask.class);
            Set<Integer> subtaskIds = new HashSet<>();

            for (JudgeSubTask task : tasks) {
                // 检查子任务ID唯一性
                if (!subtaskIds.add(task.getSubtaskId())) {
                    throw new BusinessException(ErrorCode.PARAMS_ERROR, "Duplicate subtask ID:" + task.getSubtaskId());
                }
                // 检查测试用例非空
                if (CollectionUtils.isEmpty(task.getCases())) {
                    throw new BusinessException(ErrorCode.PARAMS_ERROR, "Subtasks must contain test cases");
                }
            }
        } catch (Exception e) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "The analysis of the test case failed.");
        }
    }

    @PostMapping("/upload/pdf")
    public BaseResponse<String> uploadPdf(@RequestParam("file") MultipartFile file) {
        // 1. 基础校验
        if (file == null || file.isEmpty()) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "上传文件不能为空");
        }

        // 2. 校验是否为 PDF 文件
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || !originalFilename.toLowerCase().endsWith(".pdf")) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "仅支持上传 PDF 文件");
        }

        try {
            // 3. 构建存储路径和文件名
            String fileName = UUID.randomUUID() + ".pdf";
            String uploadPath = "/your/storage/path/pdf/"; // 你可以配置成 application.yml 中的路径
            File dir = new File(uploadPath);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            // 4. 保存文件到本地
            File dest = new File(uploadPath + fileName);
            file.transferTo(dest);

            // 5. 构建文件访问 URL（示例以本地服务器为例）
            String fileUrl = "https://your-domain.com/pdf/" + fileName;

            // 6. 返回文件 URL
            return ResultUtils.success(fileUrl);

        } catch (IOException e) {
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "文件上传失败");
        }
    }


    /**
     * 获取查询包装类（用户根据哪些字段查询，根据前端传来的请求对象，得到 mybatis 框架支持的查询 QueryWrapper 类）
     *
     * @param questionQueryRequest
     * @return
     */
    @Override
    public QueryWrapper<Question> getQueryWrapper(QuestionQueryRequest questionQueryRequest) {
        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        if (questionQueryRequest == null) {
            return queryWrapper;
        }
        Long id = questionQueryRequest.getId();
        String title = questionQueryRequest.getTitle();
        String content = questionQueryRequest.getContent();
        List<String> tags = questionQueryRequest.getTags();
        Long userId = questionQueryRequest.getUserId();
        String sortField = questionQueryRequest.getSortField();
        String sortOrder = questionQueryRequest.getSortOrder();
        // 拼接查询条件
        queryWrapper.like(StringUtils.isNotBlank(title), "title", title);
        queryWrapper.like(StringUtils.isNotBlank(content), "content", content);
        //根据标签进行模糊查询
        if (CollectionUtils.isNotEmpty(tags)) {
            for (String tag : tags) {
                queryWrapper.like("tags", "\"" + tag + "\"");
            }
        }
        queryWrapper.eq(ObjectUtils.isNotEmpty(id), "id", id);
        queryWrapper.eq(ObjectUtils.isNotEmpty(userId), "userId", userId);
        queryWrapper.eq("isDelete", false);
        queryWrapper.orderBy(SqlUtils.validSortField(sortField), sortOrder.equals(CommonConstant.SORT_ORDER_ASC),
                sortField);
        return queryWrapper;
    }


    @Override
    public QuestionVO getQuestionVO(Question question, User loginUser) {
        QuestionVO questionVO = QuestionVO.objToVo(question);
        // 1. 关联查询用户信息
        Long userId = question.getUserId();
        User user = null;
        UserVO userVO = null;
        //判断查看的问题是否为自己的，如果不为自己的
        if (userId > 0) {
            if (!userId.equals(loginUser.getId())) {
                //则把userVo设置为创题人的vo
                user = userService.getById(userId);
                userVO = userService.getUserVO(user);
            }else{
                userVO = userService.getUserVO(loginUser);
            }
        }
        if (!userService.isAdmin(loginUser)) {
            questionVO.setJudgeSubTask(null);
        }
        //添加不同的语言的代码模板
        String codeTemplateStr = ResourceUtil.readUtf8Str("CodeTemplate.json");
        CodeTemplate codeTemplate = JSONUtil.toBean(codeTemplateStr, CodeTemplate.class);
        questionVO.setCodeTemplate(codeTemplate);
        questionVO.setUserVO(userVO);
        return questionVO;
    }



    @Override
    public Page<QuestionVO> getQuestionVOPage(Page<Question> questionPage) {
        List<Question> questionList = questionPage.getRecords();
        Page<QuestionVO> questionVOPage = new Page<>(questionPage.getCurrent(), questionPage.getSize(), questionPage.getTotal());
        if (CollUtil.isEmpty(questionList)) {
            return questionVOPage;
        }
        // 1. 关联查询用户信息
        //先通过questionList获取所有userId
        Set<Long> userIdSet = questionList.stream().map(Question::getUserId).collect(Collectors.toSet());
        //然后通过userIdSet获取所有user，userId作为键，把所有相同userId的user放到一个list中
        Map<Long, List<User>> userIdUserListMap = userService.listByIds(userIdSet).stream()
                .collect(Collectors.groupingBy(User::getId));
        // 填充信息
        List<QuestionVO> questionVOList = questionList.stream().map(question -> {
            //这里再通过把question中对应的user找到，赋值并转化成vo对象设置给QuestionV对象
            QuestionVO questionVO = QuestionVO.objToVo(question);
            Long userId = question.getUserId();
            User user = null;
            if (userIdUserListMap.containsKey(userId)) {
                user = userIdUserListMap.get(userId).get(0);
            }
            questionVO.setUserVO(userService.getUserVO(user));
            questionVO.setJudgeConfig(null);
            return questionVO;
        }).collect(Collectors.toList());
        questionVOPage.setRecords(questionVOList);
        return questionVOPage;
    }


}




