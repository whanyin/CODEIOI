package com.hanyin.CodeIOI.config;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.hanyin.CodeIOI.model.enums.JudgeInfoMessageEnum;
import org.springframework.boot.jackson.JsonComponent;
import org.springframework.context.annotation.Bean;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

import java.io.IOException;

/**
 * Spring MVC Json 配置
 */
@JsonComponent
public class JsonConfig {

    @Bean
    public ObjectMapper jacksonObjectMapper(Jackson2ObjectMapperBuilder builder) {
        ObjectMapper objectMapper = builder.createXmlMapper(false).build();

        SimpleModule module = new SimpleModule()
                // 处理Long类型精度丢失
                .addSerializer(Long.class, ToStringSerializer.instance)
                .addSerializer(Long.TYPE, ToStringSerializer.instance)

                // 添加枚举序列化配置（关键修改）
                .addSerializer(JudgeInfoMessageEnum.class, new JsonSerializer<JudgeInfoMessageEnum>() {
                    @Override
                    public void serialize(JudgeInfoMessageEnum value, JsonGenerator gen,
                                          SerializerProvider provider) throws IOException {
                        gen.writeString(value.getValue()); // 使用枚举的value值
                    }
                });

        objectMapper.registerModule(module);
        return objectMapper;
    }
}