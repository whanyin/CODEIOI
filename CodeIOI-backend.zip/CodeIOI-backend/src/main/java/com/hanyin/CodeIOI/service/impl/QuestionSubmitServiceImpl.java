package com.hanyin.CodeIOI.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hanyin.CodeIOI.RabbitMq.MyMessageProducer;
import com.hanyin.CodeIOI.common.ErrorCode;
import com.hanyin.CodeIOI.constant.CommonConstant;
import com.hanyin.CodeIOI.constant.MqConstant;
import com.hanyin.CodeIOI.exception.BusinessException;
import com.hanyin.CodeIOI.judge.JudgeService;
import com.hanyin.CodeIOI.judge.codeSandBox.model.JudgeResult;
import com.hanyin.CodeIOI.mapper.QuestionSubmitMapper;
import com.hanyin.CodeIOI.model.dto.questionsubmit.QuestionSubmitAddRequest;
import com.hanyin.CodeIOI.model.dto.questionsubmit.QuestionSubmitQueryRequest;
import com.hanyin.CodeIOI.model.entity.Question;
import com.hanyin.CodeIOI.model.entity.QuestionSubmit;
import com.hanyin.CodeIOI.model.entity.User;
import com.hanyin.CodeIOI.model.enums.QuestionSubmitLanguageEnum;
import com.hanyin.CodeIOI.model.enums.QuestionSubmitStatusEnum;
import com.hanyin.CodeIOI.model.enums.QuestionSubmitVisibleEnum;
import com.hanyin.CodeIOI.model.enums.UserRoleEnum;
import com.hanyin.CodeIOI.model.vo.QuestionSubmitVO;
import com.hanyin.CodeIOI.model.vo.QuestionVO;
import com.hanyin.CodeIOI.service.QuestionService;
import com.hanyin.CodeIOI.service.QuestionSubmitService;
import com.hanyin.CodeIOI.service.UserService;
import com.hanyin.CodeIOI.utils.SqlUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
public class QuestionSubmitServiceImpl extends ServiceImpl<QuestionSubmitMapper, QuestionSubmit>
    implements QuestionSubmitService{
    
    @Resource
    private QuestionService questionService;

    @Resource
    private UserService userService;

    @Resource
    @Lazy
    private JudgeService judgeService;

    @Resource
    private MyMessageProducer myMessageProducer;

    /**
     * 提交题目
     *
     * @param questionSubmitAddRequest
     * @param loginUser
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long doQuestionSubmit(QuestionSubmitAddRequest questionSubmitAddRequest, User loginUser) {
        // 校验编程语言是否合法
        String language = questionSubmitAddRequest.getLanguage();
        QuestionSubmitLanguageEnum languageEnum = QuestionSubmitLanguageEnum.getEnumByValue(language);
        if (languageEnum == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Programming language errors");
        }
        long questionId = questionSubmitAddRequest.getQuestionId();
        // 判断实体是否存在，根据类别获取实体
        Question question = questionService.getById(questionId);
        if (question == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR);
        }
        // 是否已提交题目
        long userId = loginUser.getId();
        // 每个用户串行提交题目
        QuestionSubmit questionSubmit = new QuestionSubmit();
        questionSubmit.setUserId(userId);
        questionSubmit.setQuestionId(questionId);
        questionSubmit.setCode(questionSubmitAddRequest.getCode());
        questionSubmit.setLanguage(language);
        // 设置初始状态
        questionSubmit.setStatus(QuestionSubmitStatusEnum.WAITING.getValue());
        questionSubmit.setJudgeResult("{}");
        boolean save = this.save(questionSubmit);
        if (!save){
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "Data insertion failed");
        }
        Long questionSubmitId = questionSubmit.getId();
        // 执行判题服务
        CompletableFuture.runAsync(() -> {
            judgeService.doJudge(questionSubmitId);
        });
        // 设置问题的提交数
        Integer submitNum = question.getSubmitNum();
        Question updateQuestion = new Question();
        synchronized (question.getSubmitNum()) {
            submitNum = submitNum + 1;
            updateQuestion.setId(questionId);
            updateQuestion.setSubmitNum(submitNum);
            save = questionService.updateById(updateQuestion);
            if (!save) {
                throw new BusinessException(ErrorCode.OPERATION_ERROR, "Data saving failed");
            }
        }
//        Long questionSubmitId = questionSubmit.getId();
//        // 异步调用判题服务
//        myMessageProducer.sendMessage(MqConstant.DIRECT_EXCHANGE, "oj", String.valueOf(questionSubmitId));
        return questionSubmitId;

    }


    /**
     * 获取查询包装类（用户根据哪些字段查询，根据前端传来的请求对象，得到 mybatis 框架支持的查询 QueryWrapper 类）
     *
     * @param questionQueryRequest
     * @return
     */
    @Override
    public QueryWrapper<QuestionSubmit> getQueryWrapper(QuestionSubmitQueryRequest questionQueryRequest) {
        QueryWrapper<QuestionSubmit> queryWrapper = new QueryWrapper<>();
        if (questionQueryRequest == null) {
            return queryWrapper;
        }
        String language = questionQueryRequest.getLanguage();
        Integer status = questionQueryRequest.getStatus();
        Long questionId = questionQueryRequest.getQuestionId();
        Long userId = questionQueryRequest.getUserId();
        Integer visible = questionQueryRequest.getVisible();
        String sortField = questionQueryRequest.getSortField();
        String sortOrder = questionQueryRequest.getSortOrder();
        queryWrapper.eq(ObjectUtils.isNotEmpty(language), "language", language);
        queryWrapper.eq(ObjectUtils.isNotEmpty(userId), "userId", userId);
        queryWrapper.eq(ObjectUtils.isNotEmpty(questionId), "questionId", questionId);
        queryWrapper.eq(QuestionSubmitVisibleEnum.getEnumByValue(visible) != null, "visible", visible);
        queryWrapper.eq(QuestionSubmitStatusEnum.getEnumByValue(status) != null, "status", status);
        queryWrapper.eq("isDelete", false);
        queryWrapper.orderBy(SqlUtils.validSortField(sortField), sortOrder.equals(CommonConstant.SORT_ORDER_ASC),
                sortField);
        return queryWrapper;
    }

    public QuestionSubmitVO getQuestionSubmitVO(QuestionSubmit questionSubmit, User loginUser) {
        QuestionSubmitVO questionSubmitVO = new QuestionSubmitVO();
        BeanUtils.copyProperties(questionSubmit, questionSubmitVO);

        // 处理判题结果
        if (StringUtils.isNotBlank(questionSubmit.getJudgeResult())) {
            try {
                JudgeResult judgeResult = JSONUtil.toBean(questionSubmit.getJudgeResult(), JudgeResult.class);
                questionSubmitVO.setJudgeResult(judgeResult);
            } catch (Exception e) {
                log.error("解析judgeResult失败", e);
                // 设置一个空的判题结果对象
                questionSubmitVO.setJudgeResult(new JudgeResult());
            }
        } else {
            questionSubmitVO.setJudgeResult(new JudgeResult());
        }

        // 设置用户信息（脱敏）
        if (questionSubmit.getUserId() != null) {
            User user = userService.getById(questionSubmit.getUserId());
            questionSubmitVO.setUserVO(userService.getUserVO(user));
        }

        Question question = questionService.getById(questionSubmit.getQuestionId());
        questionSubmitVO.setQuestionVO(questionService.getQuestionVO(question,loginUser));

        return questionSubmitVO;
    }

    @Override
    public Page<QuestionSubmitVO> getQuestionSubmitVOPage(Page<QuestionSubmit> questionSubmitPage, User loginUser) {
        List<QuestionSubmit> questionList = questionSubmitPage.getRecords();
        Page<QuestionSubmitVO> questionVoPage = new Page<>(questionSubmitPage.getCurrent(), questionSubmitPage.getSize(), questionSubmitPage.getTotal());
        if (CollUtil.isEmpty(questionList)) {
            return questionVoPage;
        }
        // 填充信息
        List<QuestionSubmitVO> questionVOList = questionList.stream().map(question -> {
            return this.getQuestionSubmitVO(question, loginUser);
        }).collect(Collectors.toList());
        questionVoPage.setRecords(questionVOList);
        return questionVoPage;
    }

    @Override
    public List<QuestionSubmitVO> getQuestionSubmitVOList(List<QuestionSubmit> questionSubmitList, User loginUser) {
        ArrayList<QuestionSubmitVO> questionSubmitListVo = new ArrayList<>();
        questionSubmitList.forEach(questionSubmit -> {
            QuestionSubmitVO questionSubmitVO = getQuestionSubmitVO(questionSubmit, loginUser);
            questionSubmitListVo.add(questionSubmitVO);
        });
        return questionSubmitListVo;
    }


}




