package com.hanyin.CodeIOI.judge.codeSandBox.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.hanyin.CodeIOI.model.enums.JudgeInfoMessageEnum;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class TestCaseResult {
    private String testcaseId;      // 关联的测试用例ID
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private String verdict;        // 当前用例的判题状态
    private Integer caseScore;
    private String input;           // 输入数据（便于前端显示比对）
    private String expectedOutput;  // 预期输出
    private String actualOutput;    // 实际输出
    private Boolean passed;

}
