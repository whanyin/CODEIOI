package com.hanyin.CodeIOI.exception;

import com.hanyin.CodeIOI.common.ErrorCode;

/**
 * Exception Throwing Tool Classes
 */
public class ThrowUtils {

    /**
     * Throw an exception if the condition is true
     *
     * @param condition
     * @param runtimeException
     */
    public static void throwIf(boolean condition, RuntimeException runtimeException) {
        if (condition) {
            throw runtimeException;
        }
    }

    /**
     * Throw an exception if the condition is true
     *
     * @param condition
     * @param errorCode
     */
    public static void throwIf(boolean condition, ErrorCode errorCode) {
        throwIf(condition, new BusinessException(errorCode));
    }

    /**
     * Throw an exception if the condition is true
     *
     * @param condition
     * @param errorCode
     * @param message
     */
    public static void throwIf(boolean condition, ErrorCode errorCode, String message) {
        throwIf(condition, new BusinessException(errorCode, message));
    }
}
