package com.hanyin.CodeIOI.constant;

/**
 * @author 160201
 */
public interface MqConstant {
    String DIRECT_EXCHANGE = "ojJudge.exchange";
    String DIRECT_QUEUE1 = "ojJudge.queue";

    String DLX_EXCHANGE = "dlx.exchange";
    String DLX_QUEUE = "dlx.queue";
}
