package com.hanyin.CodeIOI.judge.codeSandBox.impl;

import com.hanyin.CodeIOI.judge.codeSandBox.CodeSandBox;
import com.hanyin.CodeIOI.judge.codeSandBox.model.ExecuteCodeRequest;
import com.hanyin.CodeIOI.judge.codeSandBox.model.ExecuteCodeResponse;
import com.hanyin.CodeIOI.judge.codeSandBox.model.JudgeResult;
import com.hanyin.CodeIOI.model.enums.JudgeInfoMessageEnum;
import com.hanyin.CodeIOI.model.enums.QuestionSubmitStatusEnum;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * 示例代码沙箱（仅为了跑通业务流程）
 */
@Slf4j
public class ExampleCodeSandBox implements CodeSandBox {
    @Override
    public ExecuteCodeResponse executeCode(ExecuteCodeRequest executeCodeRequest) {
        List<String> inputList = executeCodeRequest.getInputList();
        ExecuteCodeResponse executeCodeResponse = new ExecuteCodeResponse();
        executeCodeResponse.setOutputList(inputList);
        executeCodeResponse.setMessage("测试执行成功");
        executeCodeResponse.setStatus(QuestionSubmitStatusEnum.SUCCEED.getValue());
        JudgeResult judgeResult = new JudgeResult();
//        JudgeResult.setMessage(JudgeInfoMessageEnum.ACCEPTED.getText());
//        JudgeResult.setMemory(100L);
//        JudgeResult.setTime(100L);
        executeCodeResponse.setJudgeResult(judgeResult);
        return executeCodeResponse;
    }
}
