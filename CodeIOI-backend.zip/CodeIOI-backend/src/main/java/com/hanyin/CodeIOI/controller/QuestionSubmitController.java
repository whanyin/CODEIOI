package com.hanyin.CodeIOI.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hanyin.CodeIOI.common.BaseResponse;
import com.hanyin.CodeIOI.common.ErrorCode;
import com.hanyin.CodeIOI.common.ResultUtils;
import com.hanyin.CodeIOI.exception.BusinessException;
import com.hanyin.CodeIOI.exception.ThrowUtils;
import com.hanyin.CodeIOI.model.dto.questionsubmit.QuestionSubmitAddRequest;
import com.hanyin.CodeIOI.model.dto.questionsubmit.QuestionSubmitQueryRequest;
import com.hanyin.CodeIOI.model.entity.Question;
import com.hanyin.CodeIOI.model.entity.QuestionSubmit;
import com.hanyin.CodeIOI.model.entity.User;
import com.hanyin.CodeIOI.model.vo.QuestionSubmitVO;
import com.hanyin.CodeIOI.model.vo.QuestionVO;
import com.hanyin.CodeIOI.service.QuestionService;
import com.hanyin.CodeIOI.service.QuestionSubmitService;
import com.hanyin.CodeIOI.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import com.hanyin.CodeIOI.model.vo.UserVO;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * 题目提交接口
 */
@RestController
@RequestMapping("/question_submit")
@Slf4j
public class QuestionSubmitController {

    @Resource
    private QuestionSubmitService questionSubmitService;

    @Resource
    private UserService userService;

    @Resource
    private QuestionService questionService;

    /**
     * 点赞 / 取消点赞
     *
     * @param questionSubmitAddRequest
     * @param request
     * @return resultNum 本次点赞变化数
     */
    @PostMapping("/")
    public BaseResponse<Long> doQuestionSubmit(@RequestBody QuestionSubmitAddRequest questionSubmitAddRequest,
                                               HttpServletRequest request) {
        if (questionSubmitAddRequest == null || questionSubmitAddRequest.getQuestionId() <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        // 登录才能提交
        final User loginUser = userService.getLoginUser();
        Long result = questionSubmitService.doQuestionSubmit(questionSubmitAddRequest, loginUser);
        return ResultUtils.success(result);
    }

    /**
     * 分页获取列表（封装类）
     *
     * @param questionSubmitQueryRequest
     * @param request
     * @return
     */
    @PostMapping("/list/page/vo")
    public BaseResponse<Page<QuestionSubmitVO>> listQuestionSubmitVOByPage(@RequestBody QuestionSubmitQueryRequest questionSubmitQueryRequest,
                                                                           HttpServletRequest request) {
        long current = questionSubmitQueryRequest.getCurrent();
        long size = questionSubmitQueryRequest.getPageSize();
        // 限制爬虫
        ThrowUtils.throwIf(size > 20, ErrorCode.PARAMS_ERROR);
        Page<QuestionSubmit> questionSubmitPage = questionSubmitService.page(new Page<>(current, size),
                questionSubmitService.getQueryWrapper(questionSubmitQueryRequest));
        final User loginUser = userService.getLoginUser();
        return ResultUtils.success(questionSubmitService.getQuestionSubmitVOPage(questionSubmitPage, loginUser));
    }


    /**
     * 根据 id 获取
     *
     * @param id
     * @return
     */
    @GetMapping("/get/vo")
    public BaseResponse<QuestionSubmitVO> getQuestionSubmitVOById(long id) {
        if (id <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        QuestionSubmit questionSubmit = questionSubmitService.getById(id);
        if (questionSubmit == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR);
        }
        final User loginUser = userService.getLoginUser();
        return ResultUtils.success(questionSubmitService.getQuestionSubmitVO(questionSubmit, loginUser));
    }


    @GetMapping("/get/submit/{id}")
    public BaseResponse<QuestionSubmitVO> getQuestionSubmitById(@PathVariable Long id) {
        // 1. 校验参数
        if (id <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }

        // 2. 获取提交记录
        QuestionSubmit questionSubmit = questionSubmitService.getById(id);
        if (questionSubmit == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR);
        }

        // 3. 获取登录用户（用于权限校验）
        User loginUser = userService.getLoginUser();

        // 4. 转换为VO对象
        QuestionSubmitVO questionSubmitVO = questionSubmitService.getQuestionSubmitVO(questionSubmit, loginUser);

        // 5. 关联题目信息（如果前端需要）
        Question question = questionService.getById(questionSubmit.getQuestionId());
        if (question != null) {
            questionSubmitVO.setQuestionVO(QuestionVO.objToVo(question));
        }

        return ResultUtils.success(questionSubmitVO);
    }
}
