package com.hanyin.CodeIOI.judge;

import cn.hutool.json.JSONUtil;
import com.hanyin.CodeIOI.common.ErrorCode;
import com.hanyin.CodeIOI.exception.BusinessException;
import com.hanyin.CodeIOI.judge.codeSandBox.CodeSandBox;
import com.hanyin.CodeIOI.judge.codeSandBox.CodeSandBoxFactory;
import com.hanyin.CodeIOI.judge.codeSandBox.CodeSandBoxProxy;
import com.hanyin.CodeIOI.judge.codeSandBox.model.ExecuteCodeRequest;
import com.hanyin.CodeIOI.judge.codeSandBox.model.ExecuteCodeResponse;
import com.hanyin.CodeIOI.judge.codeSandBox.model.JudgeInfo;
import com.hanyin.CodeIOI.judge.codeSandBox.model.JudgeResult;
import com.hanyin.CodeIOI.judge.codeSandBox.strategy.JudgeContext;
import com.hanyin.CodeIOI.judge.codeSandBox.strategy.JudgeManager;
import com.hanyin.CodeIOI.model.dto.question.JudgeCase;
import com.hanyin.CodeIOI.model.dto.question.JudgeSubTask;
import com.hanyin.CodeIOI.model.entity.Question;
import com.hanyin.CodeIOI.model.entity.QuestionSubmit;
import com.hanyin.CodeIOI.model.enums.QuestionSubmitStatusEnum;
import com.hanyin.CodeIOI.service.QuestionService;
import com.hanyin.CodeIOI.service.QuestionSubmitService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class JudgeServiceImpl implements JudgeService {

    @Value("${codeSandBox.type:remote}")
    private String type;
    @Resource
    private QuestionService questionService;

    @Resource
    private QuestionSubmitService questionSubmitService;

    @Resource
    private JudgeManager judgeManager;


    @Override
    @Transactional(rollbackFor = Exception.class)
    public QuestionSubmit doJudge(long questionSubmitId) {
        //先获取题目提交信息
        QuestionSubmit questionSubmit = questionSubmitService.getById(questionSubmitId);
        if (questionSubmit == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "提交信息不存在");
        }
        //根据题目提交信息获取到题目id，获取题目信息
        Long questionId = questionSubmit.getQuestionId();
        Question question = questionService.getById(questionId);
        if (question == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "题目不存在");
        }
        // 2）如果题目提交状态不为等待中，就不用重复执行了
        if (!questionSubmit.getStatus().equals(QuestionSubmitStatusEnum.WAITING.getValue())) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "题目正在判题中");
        }
        //修改题目的判题状态
        QuestionSubmit questionSubmitUpdate = new QuestionSubmit();
        questionSubmitUpdate.setStatus(QuestionSubmitStatusEnum.RUNNING.getValue());
        questionSubmitUpdate.setId(questionSubmitId);
        questionSubmitUpdate.setQuestionId(questionId);
        boolean update = questionSubmitService.updateById(questionSubmitUpdate);
        if (!update) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "题目状态更新失败");
        }
        //拿到题目提交的所有信息
        String language = questionSubmit.getLanguage();
        String code = questionSubmit.getCode();
        CodeSandBox codeSandbox = CodeSandBoxFactory.newInstance(type);
        codeSandbox = new CodeSandBoxProxy(codeSandbox);
        // 获取输入用例
        String judgeTaskStr = question.getJudgeTasks();
        List<JudgeSubTask> judgeSubTaskList = JSONUtil.toList(judgeTaskStr, JudgeSubTask.class);
        // 遍历所有 subtask，获取其中的 input
        List<String> inputList = judgeSubTaskList.stream()
                .flatMap(task -> task.getCases().stream())  // 展开 subtask 内的 cases
                .map(JudgeCase::getInput)  // 提取 input
                .collect(Collectors.toList());
        List<String> expectedOutputList = judgeSubTaskList.stream()
                .flatMap(task -> task.getCases().stream())  // 展开 subtask 内的 cases
                .map(JudgeCase::getExpectedOutput)  // 提取 expectedOutput
                .collect(Collectors.toList());
        ExecuteCodeRequest executeCodeRequest = ExecuteCodeRequest.builder()
                .code(code)
                .language(language)
                .inputList(inputList)
                .build();
        //调用远程代码沙箱
        ExecuteCodeResponse executeCodeResponse = codeSandbox.executeCode(executeCodeRequest);
        List<String> actualOutputList = executeCodeResponse.getOutputList();
        // 设置上下文
        JudgeContext judgeContext = new JudgeContext();
        judgeContext.setStatus(executeCodeResponse.getStatus());
        judgeContext.setInputList(inputList);
        judgeContext.setActualOutputList(actualOutputList);
        judgeContext.setExpectedOutputList(expectedOutputList);
        judgeContext.setJudgeInfo(executeCodeResponse.getJudgeInfo());
        judgeContext.setJudgeSubTaskList(judgeSubTaskList);
        judgeContext.setQuestion(question);
        judgeContext.setQuestionSubmit(questionSubmit);

        // 执行判题逻辑（填充 subTaskResults、totalScore 等）
        JudgeResult judgeResult = judgeManager.doJudge(judgeContext);
        if(judgeResult.getTotalScore()==100)
        {
            Integer acceptedNum = question.getAcceptedNum();
            Question updateQuestion = new Question();
            synchronized (question.getSubmitNum()) {
                acceptedNum = acceptedNum + 1;
                updateQuestion.setId(questionId);
                updateQuestion.setAcceptedNum(acceptedNum);
                boolean save = questionService.updateById(updateQuestion);
                if (!save) {
                    throw new BusinessException(ErrorCode.OPERATION_ERROR, "Data saving failed");
                }
            }
        }

        //更新题目状态
        questionSubmitUpdate.setStatus(judgeContext.getStatus());
        questionSubmitUpdate.setId(questionSubmitId);
        questionSubmitUpdate.setQuestionId(questionId);
        questionSubmitUpdate.setJudgeResult(JSONUtil.toJsonStr(judgeResult));
        update = questionSubmitService.updateById(questionSubmitUpdate);
        if (!update) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "Question status update failed");
        }
        QuestionSubmit questionSubmitResult = questionSubmitService.getById(questionId);
        return questionSubmitResult;

    }
}
