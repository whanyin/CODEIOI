package com.hanyin.CodeIOI.model.dto.question;

import com.hanyin.CodeIOI.model.enums.InputType;
import com.hanyin.CodeIOI.utils.InputParser;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
public class JudgeCase {
    // 用例信息
    private String testcaseId;     // 用例ID（如 "T1-1"）
    private Integer caseScore;     // 该用例的独立分数（即使subtask得0分，这里也记录理论值）
    private String input;          // 输入数据
    private String expectedOutput; // 预期输
}

