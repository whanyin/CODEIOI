package com.hanyin.CodeIOI.judge.codeSandBox.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@NoArgsConstructor
@Data
public class JudgeInfo {

    /**
     * 题目执行信息
     */
    private String message;

    private Long memory;

    private Long time;
}
