package com.hanyin.CodeIOI.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hanyin.CodeIOI.model.entity.QuestionSubmit;
public interface QuestionSubmitMapper extends BaseMapper<QuestionSubmit> {

}




