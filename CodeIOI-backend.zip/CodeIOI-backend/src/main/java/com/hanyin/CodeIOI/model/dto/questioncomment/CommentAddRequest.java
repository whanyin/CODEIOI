package com.hanyin.CodeIOI.model.dto.questioncomment;

import com.hanyin.CodeIOI.model.entity.QuestionComment;
import lombok.Data;

import java.io.Serializable;

/**
 * @author 160201
 */
@Data
public class CommentAddRequest implements Serializable {
    /**
     * 父级评论
     */
    private QuestionComment parentComment;

    /**
     * 当前评论
     */
    private QuestionComment currentComment;
}
