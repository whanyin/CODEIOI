package com.hanyin.CodeIOI.judge.codeSandBox.model;

import com.hanyin.CodeIOI.model.enums.JudgeInfoMessageEnum;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
public class JudgeResult {

    private String message;


    /**
     * 通过的subtask数
     */
    private Integer passSubtaskNum;

    /**
     * 总subtask数
     */
    private Integer totalSubtaskNum;

    /**
     * 总得分
     */
    private Integer totalScore;

    private Long time;      // 毫秒
    private Long memory;    // 字节


    private List<SubTaskResult> subTaskResults;

    private JudgeInfoMessageEnum verdict;


}

