package com.hanyin.CodeIOI.judge.codeSandBox.strategy;

import cn.hutool.json.JSONUtil;
import com.hanyin.CodeIOI.common.ErrorCode;
import com.hanyin.CodeIOI.exception.BusinessException;
import com.hanyin.CodeIOI.judge.codeSandBox.model.JudgeInfo;
import com.hanyin.CodeIOI.judge.codeSandBox.model.SubTaskResult;
import com.hanyin.CodeIOI.judge.codeSandBox.model.TestCaseResult;
import com.hanyin.CodeIOI.judge.codeSandBox.model.JudgeResult;
import com.hanyin.CodeIOI.model.dto.question.JudgeCase;
import com.hanyin.CodeIOI.model.dto.question.JudgeConfig;
import com.hanyin.CodeIOI.model.dto.question.JudgeSubTask;
import com.hanyin.CodeIOI.model.entity.Question;
import com.hanyin.CodeIOI.model.enums.JudgeInfoMessageEnum;
import com.hanyin.CodeIOI.service.QuestionService;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;
import java.util.*;

@Slf4j
public class DefaultJudgeStrategy implements JudgeStrategy {

    @Resource
    private QuestionService questionService;

    @Override
    public JudgeResult doJudge(JudgeContext judgeContext) {
        JudgeResult judgeResult = new JudgeResult();
        Question question = judgeContext.getQuestion();
        List<SubTaskResult> subTaskResults = new ArrayList<>();
        int totalScore = 0;
        int globalCaseIndex = 0;

        // Get basic information from context
        List<String> actualOutputs = judgeContext.getActualOutputList();
        List<String> expectedOutputs = judgeContext.getExpectedOutputList();
        List<JudgeSubTask> judgeSubTasks = judgeContext.getJudgeSubTaskList();
        JudgeInfo judgeInfo = judgeContext.getJudgeInfo();

        // First check for compilation errors or system errors
        if (judgeInfo != null && judgeInfo.getMessage() != null) {
            if (judgeInfo.getMessage().contains("Compile Error")) {
                judgeResult.setMessage("Compile Error");
                judgeResult.setTotalScore(0);
                return judgeResult;
            }
            if (judgeInfo.getMessage().contains("Runtime Error")) {
                judgeResult.setMessage("Runtime Error");
                judgeResult.setTotalScore(0);
                return judgeResult;
            }
            if (judgeInfo.getMessage().contains("Dangerous Operation")) {
                judgeResult.setMessage("Dangerous Operation");
                judgeResult.setTotalScore(0);
                return judgeResult;
            }
            if (judgeInfo.getMessage().contains("System Error")) {
                judgeResult.setMessage("System Error");
                judgeResult.setTotalScore(0);
                return judgeResult;
            }
        }
        if (judgeInfo != null) {
            String judgeConfigStr = question.getJudgeConfig();
            JudgeConfig judgeConfig = JSONUtil.toBean(judgeConfigStr, JudgeConfig.class);
            Long timeLimit = judgeConfig.getTimeLimit();
            Long memoryLimit = judgeConfig.getMemoryLimit();

            if (judgeInfo.getMemory() > memoryLimit) {
                judgeResult.setMessage(JudgeInfoMessageEnum.MEMORY_LIMIT_EXCEEDED.getValue());
                judgeResult.setTotalScore(0);
                judgeResult.setMemory(judgeInfo.getMemory());
                judgeResult.setTime(judgeResult.getTime());
                return judgeResult;
            }

            if (judgeInfo.getTime() > timeLimit) {
                judgeResult.setMessage(JudgeInfoMessageEnum.TIME_LIMIT_EXCEEDED.getValue());
                judgeResult.setTotalScore(0);
                judgeResult.setMemory(judgeInfo.getMemory());
                judgeResult.setTime(judgeInfo.getTime());
                return judgeResult;
            }
        }

        if (actualOutputs.size() != expectedOutputs.size()) {
            judgeInfo.setMessage("Output count mismatch. Expected: " +
                    expectedOutputs.size() + ", Actual: " + actualOutputs.size());
            judgeResult.setTotalScore(0);
            return judgeResult;
        }

        // 处理每个子任务
        for (JudgeSubTask subTask : judgeSubTasks) {
            SubTaskResult subTaskResult = new SubTaskResult();
            subTaskResult.setSubTaskId(subTask.getSubtaskId());
            subTaskResult.setSubTaskScore(subTask.getSubtaskScore());

            boolean allCasesPassed = true;
            List<TestCaseResult> caseResults = new ArrayList<>();

            // 处理子任务中的每个测试用例
            for (JudgeCase judgeCase : subTask.getCases()) {
                // 检查索引是否越界
                if (globalCaseIndex >= actualOutputs.size()) {
                    throw new RuntimeException("The actual output quantity is insufficient");
                }
                String actualOutput = actualOutputs.get(globalCaseIndex);
                TestCaseResult caseResult = new TestCaseResult();
                caseResult.setTestcaseId(judgeCase.getTestcaseId());
                caseResult.setExpectedOutput(judgeCase.getExpectedOutput());
                caseResult.setActualOutput(actualOutput);
                caseResult.setCaseScore(0);
                caseResult.setVerdict(JudgeInfoMessageEnum.WRONG_ANSWER.getValue());

                boolean isPassed = compareOutputs(actualOutput, judgeCase.getExpectedOutput());
                caseResult.setPassed(isPassed);
                if(isPassed)
                {
                    caseResult.setCaseScore(100);
                    caseResult.setVerdict(JudgeInfoMessageEnum.ACCEPTED.getValue());
                }
                caseResults.add(caseResult);

                if (!isPassed) {
                    allCasesPassed = false;
                }
                globalCaseIndex++; // 处理完一个用例，索引+1

            }

            // 设置子任务得分（全过则满分，否则0分）
            int earnedScore = allCasesPassed ? subTask.getSubtaskScore() : 0;
            subTaskResult.setEarnedScore(earnedScore);
            subTaskResult.setPassed(allCasesPassed);
            subTaskResult.setCaseResults(caseResults);
            subTaskResults.add(subTaskResult);
            totalScore += earnedScore;
        }
        // 4. 检查是否所有输出都已处理
        if (globalCaseIndex != actualOutputs.size()) {
            throw new RuntimeException("实际输出数量多于测试用例数量");
        }

        // 设置最终结果
        judgeResult.setSubTaskResults(subTaskResults);
        judgeResult.setTotalScore(totalScore);
        judgeResult.setMessage(getFinalMessage(totalScore, getTotalPossibleScore(judgeSubTasks)));
        judgeResult.setMemory(judgeInfo.getMemory());
        judgeResult.setTime(judgeInfo.getTime());

        return judgeResult;
    }


    // 比较输出（考虑格式差异）
    private boolean compareOutputs(String actual, String expected) {
        // 实现你的具体比较逻辑，例如：
        // 1. 去除首尾空白
        // 2. 统一换行符
        // 3. 数字精度比较（如果需要）
        return actual.trim().replace("\r", "")
                .equals(expected.trim().replace("\r", ""));
    }

    // 计算满分
    private int getTotalPossibleScore(List<JudgeSubTask> judgeSubTasks) {
        return judgeSubTasks.stream().mapToInt(JudgeSubTask::getSubtaskScore).sum();
    }

    /**
     * 根据得分情况生成最终判题结果消息
     * @param earnedScore 实际得分
     * @param totalPossibleScore 满分
     * @return 判题结果消息
     */
    private String getFinalMessage(int earnedScore, int totalPossibleScore) {
        if (earnedScore == totalPossibleScore) {
            return "Accepted";  // 全部通过
        } else if (earnedScore > 0) {
            return "Partially Accepted";  // 部分通过
        } else {
            return "Wrong Answer";  // 全部失败
        }
    }


}