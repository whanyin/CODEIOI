package com.hanyin.CodeIOI.constant;

/**
 * Common constant
 */
public interface CommonConstant {

    /**
     * ascending order
     */
    String SORT_ORDER_ASC = "ascend";

    /**
     * descending order
     */
    String SORT_ORDER_DESC = " descend";
    
}
