package com.hanyin.CodeIOI.model.enums;

public enum InputType {
    SINGLE_LINE,      // 如 "5 3"
    MULTI_LINE_GRID,  // 如 "3 3\n...\n.#."
    MULTI_LINE_ARRAY, // 如 "3\n1 2 3\n4 5 6"

}
