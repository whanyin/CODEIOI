package com.hanyin.CodeIOI.controller;

import cn.dev33.satoken.annotation.SaCheckRole;
import cn.hutool.core.lang.TypeReference;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.gson.Gson;
import com.hanyin.CodeIOI.common.BaseResponse;
import com.hanyin.CodeIOI.common.DeleteRequest;
import com.hanyin.CodeIOI.common.ErrorCode;
import com.hanyin.CodeIOI.common.ResultUtils;
import com.hanyin.CodeIOI.constant.UserConstant;
import com.hanyin.CodeIOI.exception.BusinessException;
import com.hanyin.CodeIOI.exception.ThrowUtils;
import com.hanyin.CodeIOI.model.dto.question.JudgeSubTask;
import com.hanyin.CodeIOI.manager.RedisLimiterManager;
import com.hanyin.CodeIOI.model.dto.question.*;
import com.hanyin.CodeIOI.model.dto.questionsubmit.QuestionSubmitAddRequest;
import com.hanyin.CodeIOI.model.dto.questionsubmit.QuestionSubmitQueryRequest;
import com.hanyin.CodeIOI.model.entity.Question;
import com.hanyin.CodeIOI.model.entity.QuestionSubmit;
import com.hanyin.CodeIOI.model.entity.User;
import com.hanyin.CodeIOI.model.enums.QuestionSubmitLanguageEnum;
import com.hanyin.CodeIOI.model.vo.QuestionSubmitVO;
import com.hanyin.CodeIOI.model.vo.QuestionVO;
import com.hanyin.CodeIOI.service.QuestionService;
import com.hanyin.CodeIOI.service.QuestionSubmitService;
import com.hanyin.CodeIOI.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.io.File;

import static com.hanyin.CodeIOI.constant.RedisConstant.*;
import static com.hanyin.CodeIOI.constant.RedisKeyConstant.CACHE_QUESTION_KEY;

/**
 * 题目接口
 */
@RestController
@RequestMapping("/question")
@Slf4j
public class QuestionController {

    @Resource
    private QuestionService questionService;

    @Resource
    private UserService userService;

    @Resource
    private QuestionSubmitService questionSubmitService;
    private final static Gson GSON = new Gson();

    @Resource
    private RedisLimiterManager redisLimiterManager;

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    /**
     * 创建
     *
     * @param questionAddRequest
     * @return
     */
    @PostMapping("/add")
    public BaseResponse<Long> addQuestion(@RequestBody QuestionAddRequest questionAddRequest) {
        // 1. 基础校验
        if (questionAddRequest == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        // 2. 权限校验（仅管理员可操作）
        User loginUser = userService.getLoginUser();
        if (!userService.isAdmin(loginUser)) {
            throw new BusinessException(ErrorCode.NO_AUTH_ERROR);
        }
        // 3. 数据转换
        Question question = new Question();
        BeanUtils.copyProperties(questionAddRequest, question);

        if(questionAddRequest.getTitle()!= null && StrUtil.isNotBlank(questionAddRequest.getTitle()))
        {
            question.setTitle(JSONUtil.toJsonStr(questionAddRequest.getTitle()));
        }
        else
        {
            throw  new BusinessException(ErrorCode.PARAMS_ERROR,"Title can not be empty");
        }

        if(questionAddRequest.getDifficulty()!= null && StrUtil.isNotBlank(questionAddRequest.getDifficulty()))
        {
            question.setDifficulty(JSONUtil.toJsonStr(questionAddRequest.getDifficulty()));
        }
        else
        {
            throw  new BusinessException(ErrorCode.PARAMS_ERROR,"Difficulty can not be empty");
        }
        if (questionAddRequest.getTags() != null) {
            question.setTags(JSONUtil.toJsonStr(questionAddRequest.getTags()));
        }
        List<JudgeSubTask> judgeTasks = questionAddRequest.getJudgeTasks();
        if (judgeTasks != null) {
            question.setJudgeTasks(JSONUtil.toJsonStr(judgeTasks));
        }
        JudgeConfig judgeConfig = questionAddRequest.getJudgeConfig();
        if (judgeConfig != null) {
            question.setJudgeConfig(JSONUtil.toJsonStr(judgeConfig));
        }
        String contentType = questionAddRequest.getContentType();
        String content = questionAddRequest.getContent();
        String fileUrl = questionAddRequest.getFileUrl();

        if (StrUtil.isBlank(contentType)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "The contentType cannot be empty");
        }

        if(contentType == "text" && StrUtil.isBlank(content))
        {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "The content cannot be empty");
        }
        if(contentType == "pdf" && StrUtil.isBlank(fileUrl))
        {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "The file cannot be empty");
        }

        if (!"text".equals(contentType) && !"pdf".equals(contentType)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Unsupported title content type");
        }

        question.setContentType(contentType);
        question.setFileUrl(fileUrl);
        question.setContent(content);

        questionService.validQuestion(question, true);
        question.setUserId(loginUser.getId());
        boolean result = questionService.save(question);
        ThrowUtils.throwIf(!result, ErrorCode.OPERATION_ERROR);
        long newQuestionId = question.getId();
        //如果添加了新的问题，就重新刷新缓存
        stringRedisTemplate.delete(CACHE_QUESTION_KEY);
        return ResultUtils.success(newQuestionId);
    }

    @PostMapping("/uploadPdf")
    public BaseResponse<String> uploadPdf(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
        // 1. 校验文件是否为空和类型
        if (file.isEmpty()) {
           throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        if (!file.getOriginalFilename().toLowerCase().endsWith(".pdf")) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }

        // 2. 生成唯一文件名
        String originalFilename = file.getOriginalFilename();
        String fileName = UUID.randomUUID().toString() +"-"+ file.getOriginalFilename();

        // 3. 构建绝对路径（例如 D:/project/uploads/pdf 或 /home/user/uploads/pdf）
        String uploadDir = System.getProperty("user.dir") + File.separator + "uploads" + File.separator + "pdf";
        File dir = new File(uploadDir);
        if (!dir.exists()) {
            dir.mkdirs(); // 创建目录
        }

        // 4. 构建目标文件对象
        File dest = new File(dir, fileName);
        try {
            file.transferTo(dest); // 直接使用绝对路径保存
        } catch (IOException e) {
            e.printStackTrace();
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "file upload error");
        }

        // 5. 构建文件访问 URL（示例路径，可根据部署地址调整）
        String fileUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()+"/api"
                + "/uploads/pdf/" + fileName;

        // 6. 返回成功响应
        return ResultUtils.success(fileUrl);
    }

    /**
     * 删除
     *
     * @param deleteRequest
     * @return
     */
    @PostMapping("/delete")
    public BaseResponse<Boolean> deleteQuestion(@RequestBody DeleteRequest deleteRequest) {
        if (deleteRequest == null || deleteRequest.getId() <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        User user = userService.getLoginUser();
        long id = deleteRequest.getId();
        // 判断是否存在
        Question oldQuestion = questionService.getById(id);
        ThrowUtils.throwIf(oldQuestion == null, ErrorCode.NOT_FOUND_ERROR);
        // 仅本人或管理员可删除
        if (!oldQuestion.getUserId().equals(user.getId()) && !userService.isAdmin()) {
            throw new BusinessException(ErrorCode.NO_AUTH_ERROR);
        }
        boolean b = questionService.removeById(id);
        return ResultUtils.success(b);
    }

    /**
     * 更新（仅管理员）
     *
     * @param questionUpdateRequest
     * @return
     */
    @PostMapping("/update")
    @SaCheckRole(UserConstant.ADMIN_ROLE)
    public BaseResponse<Boolean> updateQuestion(@RequestBody QuestionUpdateRequest questionUpdateRequest) {
        // 1. 基础校验
        if (questionUpdateRequest == null || questionUpdateRequest.getId() <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "参数错误");
        }
        // 2. 权限校验（通过注解已完成，此处可添加额外检查）
        User loginUser = userService.getLoginUser();

        // 3. 数据转换
        Question question = new Question();
        BeanUtils.copyProperties(questionUpdateRequest, question);

        if(questionUpdateRequest.getTitle()!= null && StrUtil.isNotBlank(questionUpdateRequest.getTitle()))
        {
            question.setTitle(JSONUtil.toJsonStr(questionUpdateRequest.getTitle()));
        }
        else
        {
            throw  new BusinessException(ErrorCode.PARAMS_ERROR,"Title can not be empty");
        }

        if(questionUpdateRequest.getDifficulty()!= null && StrUtil.isNotBlank(questionUpdateRequest.getDifficulty()))
        {
            question.setDifficulty(JSONUtil.toJsonStr(questionUpdateRequest.getDifficulty()));
        }
        else
        {
            throw  new BusinessException(ErrorCode.PARAMS_ERROR,"Difficulty can not be empty");
        }

        if (questionUpdateRequest.getDifficulty() != null) {
            question.setDifficulty(JSONUtil.toJsonStr(questionUpdateRequest.getDifficulty()));
        }
        if(questionUpdateRequest.getContentType() != null)
        {
            question.setContentType(questionUpdateRequest.getContentType());
        }
        if(questionUpdateRequest.getFileUrl() != null)
        {
            question.setFileUrl(questionUpdateRequest.getFileUrl());
        }
        // 处理tags字段
        if (questionUpdateRequest.getTags() != null) {
            question.setTags(JSONUtil.toJsonStr(questionUpdateRequest.getTags()));
        }
        // 处理judgeTasks字段
        List<JudgeSubTask> judgeTasks = questionUpdateRequest.getJudgeTasks();
        if (judgeTasks != null) {
            question.setJudgeTasks(JSONUtil.toJsonStr(judgeTasks));
        }
        // 处理judgeConfig字段
        JudgeConfig judgeConfig = questionUpdateRequest.getJudgeConfig();
        if (judgeConfig != null) {
            question.setJudgeConfig(JSONUtil.toJsonStr(judgeConfig));
        }

        String contentType = questionUpdateRequest.getContentType();
        String content = questionUpdateRequest.getContent();
        String fileUrl = questionUpdateRequest.getFileUrl();

        if (StrUtil.isBlank(contentType)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "The contentType cannot be empty");
        }

        if(contentType == "text" && StrUtil.isBlank(content))
        {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "The content cannot be empty");
        }
        if(contentType == "pdf" && StrUtil.isBlank(fileUrl))
        {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "The file cannot be empty");
        }

        if (!"text".equals(contentType) && !"pdf".equals(contentType)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Unsupported title content type");
        }
        // 参数校验
        questionService.validQuestion(question, false);
        long id = questionUpdateRequest.getId();
        // 判断是否存在
        Question oldQuestion = questionService.getById(id);
        ThrowUtils.throwIf(oldQuestion == null, ErrorCode.NOT_FOUND_ERROR);
        boolean result = questionService.updateById(question);
        ThrowUtils.throwIf(!result, ErrorCode.OPERATION_ERROR, "更新失败");

        return ResultUtils.success(true);
    }

    /**
     * 根据 id 获取
     *
     * @param id
     * @return
     */
    @GetMapping("/get/vo")
    public BaseResponse<QuestionVO> getQuestionVOById(long id) {
        User loginUser = userService.getLoginUser();
        if (id <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        String key = CACHE_QUESTION_KEY + id;
//        String questionJson = stringRedisTemplate.opsForValue().get(key);
//        if (StrUtil.isNotBlank(questionJson)) {
//            //命中直接返回
//            Question question = JSONUtil.toBean(questionJson, Question.class);
//            return ResultUtils.success(questionService.getQuestionVO(question, loginUser));
//        }
        Question question = questionService.getById(id);
        if (question == null) {
            stringRedisTemplate.opsForValue().set(key, "_null_", CACHE_NULL_TTL + RandomUtil.randomLong(1, 10), TimeUnit.MINUTES);
            //不存在，直接报错，返回一个空
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR);
        } else {
            //缓存到redis中，加入随机的缓存时间防止缓存穿透
            stringRedisTemplate.opsForValue().set(key, JSONUtil.toJsonStr(question), CACHE_QUESTION_TTL + RandomUtil.randomLong(1, 3), TimeUnit.MINUTES);
        }
        return ResultUtils.success(questionService.getQuestionVO(question, loginUser));
    }


    @GetMapping("/languages")
    public BaseResponse<List<String>> getAllLanguages() {
        List<String> statusMap = new ArrayList<>();
        for (QuestionSubmitLanguageEnum status : QuestionSubmitLanguageEnum.values()) {
            statusMap.add(status.getValue());
        }
        return ResultUtils.success(statusMap);
    }

    /**
     * 分页获取列表（仅管理员）
     *
     * @param questionQueryRequest
     * @return
     */
    @PostMapping("/list/page")
    @SaCheckRole(UserConstant.ADMIN_ROLE)
    public BaseResponse<Page<Question>> listQuestionByPage(@RequestBody QuestionQueryRequest questionQueryRequest) {
        long current = questionQueryRequest.getCurrent();
        long size = questionQueryRequest.getPageSize();
        Page<Question> questionPage = questionService.page(new Page<>(current, size), questionService.getQueryWrapper(questionQueryRequest));
        return ResultUtils.success(questionPage);
    }


    /**
     * 分页获取列表（封装类）
     *
     * @param questionQueryRequest
     * @param request
     * @return
     */
//    @PostMapping("/list/page/vo")
//    public BaseResponse<Page<QuestionVO>> listQuestionVOByPage(@RequestBody QuestionQueryRequest questionQueryRequest, HttpServletRequest request) {
//        long current = questionQueryRequest.getCurrent();
//        long size = questionQueryRequest.getPageSize();
//
//        // 限制爬虫
//        ThrowUtils.throwIf(size > 20, ErrorCode.PARAMS_ERROR);
//        String pageJson = stringRedisTemplate.opsForValue().get(CACHE_QUESTION_KEY + current);
//        Page<Question> questionPage = null;
//        Page<QuestionVO> questionVoPage = null;
//        //将分页查询到的数据缓存到redis
//        if (StrUtil.isBlank(pageJson)) {
//            //3.从数据库取出来之后
//            questionPage = questionService.page(new Page<>(current, size), questionService.getQueryWrapper(questionQueryRequest));
//            questionVoPage = questionService.getQuestionVOPage(questionPage);
//            //4.再次缓存到redis,设置缓存的过期时间，30分钟，重新缓存查询一次
//            stringRedisTemplate.opsForValue().set(CACHE_QUESTION_KEY + current, JSONUtil.toJsonStr((questionVoPage)), CACHE_QUESTION_PAGE_TTL, TimeUnit.MINUTES);
//        } else {
//            log.info("加载缓存");
//            questionVoPage = JSONUtil.toBean(pageJson, new TypeReference<Page<QuestionVO>>() {
//            }, true);
//        }
//        return ResultUtils.success(questionVoPage);
//    }

    @PostMapping("/list/page/vo")
    public BaseResponse<Page<QuestionVO>> listQuestionVOByPage(@RequestBody QuestionQueryRequest questionQueryRequest, HttpServletRequest request) {
        long current = questionQueryRequest.getCurrent();
        long size = questionQueryRequest.getPageSize();

        // 限制爬虫
        ThrowUtils.throwIf(size > 20, ErrorCode.PARAMS_ERROR);
        // 直接从数据库查询分页数据
        Page<Question> questionPage = questionService.page(new Page<>(current, size), questionService.getQueryWrapper(questionQueryRequest));
        Page<QuestionVO> questionVoPage = questionService.getQuestionVOPage(questionPage);

        return ResultUtils.success(questionVoPage);
    }



    /**
     * 分页获取当前用户创建的资源列表
     *
     * @param questionQueryRequest
     * @return
     */
    @PostMapping("/my/list/page/vo")
    public BaseResponse<Page<QuestionVO>> listMyQuestionVOByPage(@RequestBody QuestionQueryRequest questionQueryRequest) {
        if (questionQueryRequest == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        User loginUser = userService.getLoginUser();
        questionQueryRequest.setUserId(loginUser.getId());
        long current = questionQueryRequest.getCurrent();
        long size = questionQueryRequest.getPageSize();
        // 限制爬虫
        ThrowUtils.throwIf(size > 20, ErrorCode.PARAMS_ERROR);
        Page<Question> questionPage = questionService.page(new Page<>(current, size), questionService.getQueryWrapper(questionQueryRequest));
        return ResultUtils.success(questionService.getQuestionVOPage(questionPage));
    }


    // endregion

    /**
     * 编辑（用户）
     *
     * @param questionEditRequest
     * @param request
     * @return
     */
    @PostMapping("/edit")
    public BaseResponse<Boolean> editQuestion(@RequestBody QuestionEditRequest questionEditRequest, HttpServletRequest request) {
        if (questionEditRequest == null || questionEditRequest.getId() <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        Question question = new Question();
        BeanUtils.copyProperties(questionEditRequest, question);
        List<String> tags = questionEditRequest.getTags();
        if (tags != null) {
            question.setTags(JSONUtil.toJsonStr(tags));
        }
        List<JudgeSubTask> judgeSubTasks = questionEditRequest.getJudgeSubTask();
        if (judgeSubTasks != null) {
            question.setJudgeTasks(JSONUtil.toJsonStr(judgeSubTasks));
        }
        JudgeConfig judgeConfig = questionEditRequest.getJudgeConfig();
        if (judgeConfig != null) {
            question.setJudgeConfig(JSONUtil.toJsonStr(judgeConfig));
        }
        // 参数校验
        questionService.validQuestion(question, false);
        User loginUser = userService.getLoginUser();
        long id = questionEditRequest.getId();
        // 判断是否存在
        Question oldQuestion = questionService.getById(id);
        ThrowUtils.throwIf(oldQuestion == null, ErrorCode.NOT_FOUND_ERROR);
        // 仅本人或管理员可编辑
        if (!oldQuestion.getUserId().equals(loginUser.getId()) && !userService.isAdmin(loginUser)) {
            throw new BusinessException(ErrorCode.NO_AUTH_ERROR);
        }
        boolean result = questionService.updateById(question);
        return ResultUtils.success(result);
    }

    /**
     * 提交答案
     *
     * @param id 提交id
     * @return resultNum 本次点赞变化数
     */
    @GetMapping("/question_submit/get/id")
    public BaseResponse<QuestionSubmitVO> getJudgeResult(Long id) {
        User loginUser = userService.getLoginUser();
        if (id <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        QuestionSubmit questionSubmit = questionSubmitService.getById(id);
        if (questionSubmit == null) {
            //不存在，直接报错，返回一个空
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "Submit answer does not exist");
        }
        QuestionSubmitVO questionCommentVO = questionSubmitService.getQuestionSubmitVO(questionSubmit, loginUser);
        return ResultUtils.success(questionCommentVO);
    }

    /**
     * 提交题目
     *
     * @param questionSubmitAddRequest
     * @return 提交记录的 id
     */
    @PostMapping("/question_submit/do")
    public BaseResponse<Long> doQuestionSubmit(@RequestBody QuestionSubmitAddRequest questionSubmitAddRequest) {
        if (questionSubmitAddRequest == null || questionSubmitAddRequest.getQuestionId() <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        // 登录才能提交
        final User loginUser = userService.getLoginUser();
        long questionSubmitId = questionSubmitService.doQuestionSubmit(questionSubmitAddRequest, loginUser);
        return ResultUtils.success(questionSubmitId);
    }

    /**
     * 分页获取列表（封装类）
     *
     * @param questionSubmitQueryRequest
     * @return
     */
    @PostMapping("question_submit/list/page/vo")
    public BaseResponse<Page<QuestionSubmitVO>> listQuestionSubmitVOByPage(@RequestBody QuestionSubmitQueryRequest questionSubmitQueryRequest) {
        long current = questionSubmitQueryRequest.getCurrent();
        long size = questionSubmitQueryRequest.getPageSize();
        // 限制爬虫
        ThrowUtils.throwIf(size > 20, ErrorCode.PARAMS_ERROR);
        Page<QuestionSubmit> questionSubmitPage = questionSubmitService.page(new Page<>(current, size),
                questionSubmitService.getQueryWrapper(questionSubmitQueryRequest));
        final User loginUser = userService.getLoginUser();
        return ResultUtils.success(questionSubmitService.getQuestionSubmitVOPage(questionSubmitPage, loginUser));
    }

    @PostMapping("question_submit/my/list/page/vo")
    public BaseResponse<Page<QuestionSubmitVO>> listMyQuestionSubmitVOByPage(@RequestBody QuestionSubmitQueryRequest questionSubmitQueryRequest) {
        long current = questionSubmitQueryRequest.getCurrent();
        long size = questionSubmitQueryRequest.getPageSize();
        User loginUser = userService.getLoginUser();
        questionSubmitQueryRequest.setUserId(loginUser.getId());
        // 限制爬虫
        ThrowUtils.throwIf(size > 20, ErrorCode.PARAMS_ERROR);
        Page<QuestionSubmit> questionSubmitPage = questionSubmitService.page(new Page<>(current, size),
                questionSubmitService.getQueryWrapper(questionSubmitQueryRequest));
        return ResultUtils.success(questionSubmitService.getQuestionSubmitVOPage(questionSubmitPage, loginUser));
    }


    /**
     * 根据 id 获取
     *
     * @param id
     * @return
     */
    @GetMapping("/question_submit/get/vo")
    public BaseResponse<QuestionSubmitVO> getQuestionSubmitVOById(long id) {
        if (id <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        QuestionSubmit questionSubmit = questionSubmitService.getById(id);
        if (questionSubmit == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR);
        }
        final User loginUser = userService.getLoginUser();
        return ResultUtils.success(questionSubmitService.getQuestionSubmitVO(questionSubmit, loginUser));
    }

    @PostMapping("question_submit/my_record/list/vo")
    public BaseResponse<List<QuestionSubmitVO>> listMyQuestionSubmitVORecord(@RequestBody QuestionSubmitQueryRequest questionSubmitQueryRequest) {
        User loginUser = userService.getLoginUser();
        questionSubmitQueryRequest.setUserId(loginUser.getId());

        // 获取所有 QuestionSubmit 记录
        List<QuestionSubmit> questionSubmitList = questionSubmitService.list(questionSubmitService.getQueryWrapper(questionSubmitQueryRequest));

        // 将 QuestionSubmit 列表转换为 QuestionSubmitVO 列表
        List<QuestionSubmitVO> questionSubmitVOList = questionSubmitService.getQuestionSubmitVOList(questionSubmitList, loginUser);

        // 返回数据
        return ResultUtils.success(questionSubmitVOList);
    }

}
