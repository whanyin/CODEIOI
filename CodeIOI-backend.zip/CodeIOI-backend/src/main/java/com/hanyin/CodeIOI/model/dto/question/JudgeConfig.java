package com.hanyin.CodeIOI.model.dto.question;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;
@NoArgsConstructor
@Data

public class JudgeConfig {
    private Long timeLimit;
    private Long memoryLimit;
}