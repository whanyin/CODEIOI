package com.hanyin.CodeIOI.model.dto.question;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
public class JudgeSubTask {

    private Integer subtaskId;       // 子任务ID
    private Integer subtaskScore;   // 子任务总分（仅当全部case通过时获得）
    private List<JudgeCase> cases;  // 所有测试用例（全部执行）
}

