package com.hanyin.CodeIOI.common;

/**
 * 自定义错误码
 */
public enum ErrorCode {

    SUCCESS(0, "ok"),
    PARAMS_ERROR(40000, "Request parameter error"),
    NOT_LOGIN_ERROR(40100, "Not login"),
    NO_AUTH_ERROR(40101, "No authority"),
    NOT_FOUND_ERROR(40400, "Requested data does not exist"),
    FORBIDDEN_ERROR(40300, "Disable access"),
    SYSTEM_ERROR(50000, "Internal system anomalies"),
    OPERATION_ERROR(50001, "Failure of an operation"),
    API_REQUEST_ERROR(50010,"Remote interface call failed"),
    TOO_MANY_REQUEST(50011,"Request exceeds limit"),

    INVALID_TOKEN_ERROR(401002,"Login failure"),

    BE_REPLACED_MESSAGE(401003,"Account remote login"),

    TOKEN_TIMEOUT_MESSAGE(401004,"Login expired"),
    KICK_OUT_ERROR(401005,"You have been kicked off the line"),
    TOKEN_FREEZE_ERROR(401006,"The account has been frozen");
    /**
     * 状态码
     */
    private final int code;

    /**
     * 信息
     */
    private final String message;

    ErrorCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

}
