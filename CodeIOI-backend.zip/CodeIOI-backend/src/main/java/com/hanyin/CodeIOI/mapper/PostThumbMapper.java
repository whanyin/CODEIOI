package com.hanyin.CodeIOI.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hanyin.CodeIOI.model.entity.PostThumb;

/**
 * 帖子点赞数据库操作
 */
public interface PostThumbMapper extends BaseMapper<PostThumb> {

}




