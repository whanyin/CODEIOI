package com.hanyin.CodeIOI.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;

public class JsonUtils {
    private static final ObjectMapper mapper = new ObjectMapper();

    /**
     * 验证并压缩JSON字符串
     * @param rawJson 原始JSON字符串
     * @return 压缩后的JSON字符串（无空格）
     * @throws IllegalArgumentException 当JSON无效时抛出
     */
    public static String validateAndMinify(String rawJson) {
        try {
            JsonNode node = mapper.readTree(rawJson);  // 验证JSON有效性
            return mapper.writeValueAsString(node);    // 压缩输出
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Invalid JSON: " + e.getMessage());
        }
    }
}
