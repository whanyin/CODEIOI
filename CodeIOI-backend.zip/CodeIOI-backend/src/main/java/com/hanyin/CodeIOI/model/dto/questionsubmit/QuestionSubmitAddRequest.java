package com.hanyin.CodeIOI.model.dto.questionsubmit;

import lombok.Data;

/**
 * @author 160201
 */
@Data
public class QuestionSubmitAddRequest {
    /**
     * 编程语言
     */
    private String language;

    /**
     * 用户代码
     */
    private String code;

    /**
     * 题目 id
     */
    private Long questionId;


    private static final long serialVersionUID = 1L;
}
