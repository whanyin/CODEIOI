package com.hanyin.CodeIOI.judge.codeSandBox.impl;

import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import com.hanyin.CodeIOI.common.ErrorCode;
import com.hanyin.CodeIOI.exception.BusinessException;
import com.hanyin.CodeIOI.judge.codeSandBox.CodeSandBox;
import com.hanyin.CodeIOI.judge.codeSandBox.model.ExecuteCodeRequest;
import com.hanyin.CodeIOI.judge.codeSandBox.model.ExecuteCodeResponse;
import org.apache.commons.lang3.StringUtils;

import static com.hanyin.CodeIOI.constant.AuthConstant.AUTHREQUESTHEADER;
import static com.hanyin.CodeIOI.constant.AuthConstant.AUTHREQUESTSECRET;

/**
 * 远程代码沙箱（实际调用接口的沙箱）
 */
public class RemoteCodeSandBox implements CodeSandBox {
    @Override
    public ExecuteCodeResponse executeCode(ExecuteCodeRequest executeCodeRequest) {
        System.out.println("Remote Code Sandbox");
        String url = "http://localhost:8123/executeCode";
        String json = JSONUtil.toJsonStr(executeCodeRequest);
        String responseStr = HttpUtil.createPost(url)
                .header(AUTHREQUESTHEADER , AUTHREQUESTSECRET)
                .body(json)
                .execute()
                .body();
        if (StringUtils.isBlank(responseStr)) {
            throw new BusinessException(ErrorCode.API_REQUEST_ERROR, "executeCode remoteSandbox error, message = " + responseStr);
        }
        System.out.println(responseStr);
        return JSONUtil.toBean(responseStr, ExecuteCodeResponse.class);
    }
}
