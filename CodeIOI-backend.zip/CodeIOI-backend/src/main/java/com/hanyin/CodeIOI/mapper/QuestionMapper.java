package com.hanyin.CodeIOI.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hanyin.CodeIOI.model.entity.Question;

public interface QuestionMapper extends BaseMapper<Question> {

}




