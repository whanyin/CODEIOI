
create database if not exists CodeIOI;

use CodeIOI;

-- auto-generated definition
create table user
(
    id           bigint auto_increment comment 'id'
        primary key,
    userAccount  varchar(256)                           not null comment 'account',
    userPassword varchar(512)                           not null comment 'password',
    userName     varchar(256)                           null comment 'name',
    userAvatar   varchar(1024)                          null comment 'avatar',
    userProfile  varchar(512)                           null comment 'profile',
    userRole     varchar(256) default 'user'            not null comment 'userRole：user/admin/ban',
    createTime   datetime     default CURRENT_TIMESTAMP not null comment 'createTime',
    updateTime   datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment 'update time',
    isDelete     tinyint      default 0                 not null comment 'is delete?'
)
    comment 'user' collate = utf8mb4_unicode_ci;

-- auto-generated definition
create table question
(
    id          bigint auto_increment comment 'id'
        primary key,
    title       varchar(512)                       null comment 'title',
    contentType text                               null,
    content     text                               null comment 'content',
    fileUrl     text                               null,
    difficulty  varchar(1024)                      null comment 'difficulty',
    tags        varchar(1024)                      null comment 'tags（json arr）',
    submitNum   int      default 0                 not null comment 'submit number',
    acceptedNum int      default 0                 not null comment 'accepted number',
    judgeTasks  text                               null comment 'judge task（json arr）',
    judgeConfig text                               null comment 'judge config（json object）',
    userId      bigint                             not null comment 'user id',
    createTime  datetime default CURRENT_TIMESTAMP not null comment 'create time',
    updateTime  datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment 'update time',
    isDelete    tinyint  default 0                 not null comment 'is delete'
)
    comment 'question' collate = utf8mb4_unicode_ci;

create index idx_userId
    on question (userId);

-- auto-generated definition
create table question_submit
(
    id          bigint auto_increment comment 'id'
        primary key,
    language    varchar(128)                       not null comment 'programming language',
    code        text                               not null comment 'code',
    judgeResult text                               null comment 'judge result（json object）',
    status      int      default 0                 not null comment 'status（0 - pending、1 - doing、2 - success、3 - fail）',
    questionId  bigint                             not null comment 'question id',
    userId      bigint                             not null comment 'user id',
    createTime  datetime default CURRENT_TIMESTAMP not null comment 'create time',
    updateTime  datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment 'update time',
    isDelete    tinyint  default 0                 not null comment 'is delete'
)
    comment 'question_submit';

create index idx_questionId
    on question_submit (questionId);

create index idx_userId
    on question_submit (userId);


create table contest
(
    id          bigint auto_increment comment 'id'
        primary key,
    title       varchar(512)                       null comment 'title',
    content     text                               null comment 'content',
    description varchar(1024)               null comment 'description',
    questionList       varchar(1024)                      null comment 'question（json arr）',
    userList       varchar(1024)                      null comment 'users（json arr）',
    startTime   datetime default CURRENT_TIMESTAMP not null comment 'start time',
    endTime  datetime default CURRENT_TIMESTAMP not null comment 'end time',
    createTime  datetime default CURRENT_TIMESTAMP not null comment 'create time',
    updateTime  datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment 'update time',
    isDelete    tinyint  default 0                 not null comment 'is delete'
)
    comment 'question' collate = utf8mb4_unicode_ci;



