/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { TestCaseResult } from './TestCaseResult';

export type SubTaskResult = {
    caseResults?: Array<TestCaseResult>;
    earnedScore?: number;
    passed?: boolean;
    subTaskId?: number;
    subTaskScore?: number;
};
