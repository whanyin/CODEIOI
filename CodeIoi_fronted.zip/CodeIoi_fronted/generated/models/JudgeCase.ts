/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type JudgeCase = {
    caseScore?: number;
    expectedOutput?: string;
    input?: string;
    testcaseId?: string;
};
