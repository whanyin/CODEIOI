/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type BaseResponse_List_string_ = {
    code?: number;
    data?: Array<string>;
    message?: string;
};
