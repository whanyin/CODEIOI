/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PostVO } from './PostVO';

export type BaseResponse_PostVO_ = {
    code?: number;
    data?: PostVO;
    message?: string;
};
