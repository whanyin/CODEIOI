/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { CodeTemplate } from './CodeTemplate';
import type { JudgeConfig } from './JudgeConfig';
import type { JudgeSubTask } from './JudgeSubTask';
import type { UserVO } from './UserVO';

export type QuestionVO = {
    acceptedNum?: number;
    answer?: string;
    codeTemplate?: CodeTemplate;
    difficulty?:string;
    contentType?:string;
    content?: string;
    fileUrl?: string;
    createTime?: string;
    id?: number;
    judgeConfig?: JudgeConfig;
    judgeSubTask?: Array<JudgeSubTask>;
    submitNum?: number;
    tags?: Array<string>;
    title?: string;
    updateTime?: string;
    userId?: number;
    userVO?: UserVO;
};
