/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { Page_User_ } from './Page_User_';

export type BaseResponse_Page_User_ = {
    code?: number;
    data?: Page_User_;
    message?: string;
};
