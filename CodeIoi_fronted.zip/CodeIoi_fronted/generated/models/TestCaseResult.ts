/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type TestCaseResult = {
    actualOutput?: string;
    caseScore?: number;
    expectedOutput?: string;
    input?: string;
    passed?: boolean;
    testcaseId?: string;
    verdict?: string;
};
