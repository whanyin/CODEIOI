/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { JudgeCase } from './JudgeCase';

export type JudgeSubTask = {
    cases?: Array<JudgeCase>;
    subtaskId?: number;
    subtaskScore?: number;
};
