/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { JudgeConfig } from './JudgeConfig';
import type { JudgeSubTask } from './JudgeSubTask';

export type QuestionEditRequest = {
    answer?: string;
    content?: string;
    id?: number;
    judgeConfig?: JudgeConfig;
    judgeSubTask?: Array<JudgeSubTask>;
    tags?: Array<string>;
    title?: string;
};
