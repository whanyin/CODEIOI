/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { QuestionSubmitVO } from './QuestionSubmitVO';

export type BaseResponse_QuestionSubmitVO_ = {
    code?: number;
    data?: QuestionSubmitVO;
    message?: string;
};
