/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { JudgeConfig } from './JudgeConfig';
import type { JudgeSubTask } from './JudgeSubTask';

export type QuestionUpdateRequest = {
    content?: string;
    id?: number;
    contentType?: string;
    judgeConfig?: JudgeConfig;
    judgeTasks?: Array<JudgeSubTask>;
    tags?: Array<string>;
    title?: string;
};
