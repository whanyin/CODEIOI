/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { QuestionSubmitVO } from './QuestionSubmitVO';

export type BaseResponse_List_QuestionSubmitVO_ = {
    code?: number;
    data?: Array<QuestionSubmitVO>;
    message?: string;
};
