/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { SubTaskResult } from './SubTaskResult';

export type JudgeResult = {
    memory?: number;
    message?: string;
    passSubtaskNum?: number;
    subTaskResults?: Array<SubTaskResult>;
    time?: number;
    totalScore?: number;
    totalSubtaskNum?: number;
    verdict?: JudgeResult.verdict;
};

export namespace JudgeResult {

    export enum verdict {
        ACCEPTED = 'ACCEPTED',
        WRONG_ANSWER = 'WRONG_ANSWER',
        COMPILE_ERROR = 'COMPILE_ERROR',
        MEMORY_LIMIT_EXCEEDED = 'MEMORY_LIMIT_EXCEEDED',
        TIME_LIMIT_EXCEEDED = 'TIME_LIMIT_EXCEEDED',
    }


}
