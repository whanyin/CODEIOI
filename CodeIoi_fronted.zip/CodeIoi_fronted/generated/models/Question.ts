/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type Question = {
    acceptedNum?: number;
    content?: string;
    contentType?: string;
    createTime?: string;
    difficulty?: string;
    id?: number;
    isDelete?: number;
    judgeConfig?: string;
    judgeTasks?: string;
    submitNum?: number;
    tags?: string;
    title?: string;
    updateTime?: string;
    userId?: number;
};
